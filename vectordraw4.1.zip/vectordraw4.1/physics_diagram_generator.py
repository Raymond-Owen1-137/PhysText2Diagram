import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import webbrowser
import json
import math
import numpy as np
import os
import threading
from pathlib import Path

# Try to import clipboard functionality
try:
    import pyperclip
    CLIPBOARD_AVAILABLE = True
except ImportError:
    CLIPBOARD_AVAILABLE = False

# Check if manim is available
try:
    from manim import Scene, WHITE, Line, Arc, Square, Arrow, Text
    from manim import BLUE, GRAY, GREEN, RED, RED_D, YELLOW, PURPLE, BLACK, DOWN, RIGHT, UP
    from manim import config
    MANIM_AVAILABLE = True
except ImportError:
    MANIM_AVAILABLE = False

class PhysicsGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Physics Diagram Generator - Enhanced Version")
        self.root.geometry("1200x800")
        self.root.minsize(800, 600)

        # Configure style
        style = ttk.Style()
        style.theme_use('clam')  # More modern look on Windows

        # Initialize variables
        self.current_json = None
        self.output_directory = Path.cwd() / "physics_outputs"
        self.output_directory.mkdir(exist_ok=True)

        # Create menu bar
        self.create_menu_bar()

        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Create all tabs
        self.create_text_to_json_tab()
        self.create_json_result_tab()
        self.create_3d_prompt_tab()
        self.create_batch_tab()
        self.create_settings_tab()

        # Status/log area
        self.create_log_area()

        # Initial status
        self.log_initial_status()

    def create_menu_bar(self):
        """Create application menu bar."""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Open JSON...", command=self.load_json_file)
        file_menu.add_command(label="Save JSON As...", command=self.save_json_as)
        file_menu.add_separator()
        file_menu.add_command(label="Set Output Directory...", command=self.set_output_directory)
        file_menu.add_command(label="Open Output Directory", command=self.open_output_folder)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)

        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)

    def create_text_to_json_tab(self):
        """Create Tab 1: Text to JSON conversion."""
        self.tab1 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab1, text="📝 Text → JSON")

        # Create main frame with padding
        main_frame = ttk.Frame(self.tab1)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Problem input section
        input_frame = ttk.LabelFrame(main_frame, text="Physics Problem Input", padding=10)
        input_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        # Sample problems dropdown
        sample_frame = ttk.Frame(input_frame)
        sample_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(sample_frame, text="Sample Problems:").pack(side=tk.LEFT, padx=(0, 10))
        self.sample_var = tk.StringVar()
        sample_combo = ttk.Combobox(sample_frame, textvariable=self.sample_var, width=40)
        sample_combo['values'] = [
            "A 2.0 kg block rests on a 30° frictionless incline.",
            "A 5.0 kg block slides down a 45° incline with friction coefficient 0.3",
            "Two blocks (3kg and 2kg) connected by rope over pulley on 60° incline"
        ]
        sample_combo.pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(sample_frame, text="Load Sample", command=self.load_sample).pack(side=tk.LEFT)

        self.problem_text = scrolledtext.ScrolledText(input_frame, height=8, font=("Consolas", 10))
        self.problem_text.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        self.problem_text.insert(tk.END, "A 2.0 kg block rests on a 30° frictionless incline.")

        # Buttons section
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Button(button_frame, text="🤖 Generate ChatGPT Prompt",
                  command=self.generate_prompt).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="📋 Copy Prompt",
                  command=self.copy_prompt).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="🌐 Open ChatGPT",
                  command=self.open_chatgpt).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="🔄 Clear",
                  command=self.clear_prompt).pack(side=tk.LEFT)

        # Prompt output section
        output_frame = ttk.LabelFrame(main_frame, text="Generated ChatGPT Prompt", padding=10)
        output_frame.pack(fill=tk.BOTH, expand=True)

        self.output_text = scrolledtext.ScrolledText(output_frame, height=12, font=("Consolas", 9),
                                                   bg="#f8f9fa", wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True)

    def create_json_result_tab(self):
        """Create Tab 2: JSON to diagram conversion."""
        self.tab2 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab2, text="📋 JSON Result")

        main_frame = ttk.Frame(self.tab2)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # JSON input section
        input_frame = ttk.LabelFrame(main_frame, text="JSON from ChatGPT", padding=10)
        input_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        self.json_text = scrolledtext.ScrolledText(input_frame, height=15, font=("Consolas", 10))
        self.json_text.pack(fill=tk.BOTH, expand=True)

        # JSON buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Button(button_frame, text="✅ Validate JSON",
                  command=self.validate_json).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="📁 Load JSON File",
                  command=self.load_json_file).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="💾 Save JSON",
                  command=self.save_json).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="🎬 Generate Diagram",
                  command=self.generate_manim_diagram).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="🎨 Generate 3D Prompt",
                  command=self.generate_3d_prompt).pack(side=tk.LEFT, padx=(0, 5))

        # Progress bar for diagram generation
        self.progress_frame = ttk.Frame(main_frame)
        self.progress_frame.pack(fill=tk.X, pady=(0, 10))

        self.progress_bar = ttk.Progressbar(self.progress_frame, mode='indeterminate')
        self.progress_label = ttk.Label(self.progress_frame, text="")

    def create_3d_prompt_tab(self):
        """Create Tab 3: 3D image prompt generation."""
        self.tab3 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab3, text="🎨 3D Image Prompt")

        main_frame = ttk.Frame(self.tab3)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 3D prompt section
        prompt_frame = ttk.LabelFrame(main_frame, text="3D Image Prompt for AI Image Generators", padding=10)
        prompt_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        self.prompt_3d_text = scrolledtext.ScrolledText(prompt_frame, height=20, font=("Consolas", 9),
                                                      bg="#f8f9fa", wrap=tk.WORD)
        self.prompt_3d_text.pack(fill=tk.BOTH, expand=True)

        # 3D buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X)

        ttk.Button(button_frame, text="📋 Copy 3D Prompt",
                  command=self.copy_3d_prompt).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="🌐 Open ChatGPT",
                  command=self.open_chatgpt).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="🎨 Open DALL-E",
                  command=lambda: webbrowser.open("https://openai.com/dall-e-2")).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="💾 Save Prompt",
                  command=self.save_3d_prompt).pack(side=tk.LEFT)

    def create_batch_tab(self):
        """Create Tab 4: Batch processing."""
        self.tab4 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab4, text="⚡ Batch Generator")

        main_frame = ttk.Frame(self.tab4)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Batch Settings
        batch_settings_frame = ttk.LabelFrame(main_frame, text="Batch Generation Settings", padding=10)
        batch_settings_frame.pack(fill=tk.X, pady=(0, 10))

        # Template selection
        template_row = ttk.Frame(batch_settings_frame)
        template_row.pack(fill=tk.X, pady=2)

        ttk.Label(template_row, text="Template:").pack(side=tk.LEFT, padx=(0, 5))
        self.batch_template_var = tk.StringVar(value="incline_plane")
        template_combo = ttk.Combobox(template_row, textvariable=self.batch_template_var,
                                    values=["incline_plane", "pulley_incline", "friction_incline"],
                                    state="readonly", width=15)
        template_combo.pack(side=tk.LEFT, padx=(0, 10))

        # Parameter ranges in a more organized layout
        params_frame = ttk.LabelFrame(batch_settings_frame, text="Parameter Ranges", padding=5)
        params_frame.pack(fill=tk.X, pady=5)

        # Create parameter input grid
        self.create_parameter_inputs(params_frame)

        # Output settings
        output_frame = ttk.LabelFrame(batch_settings_frame, text="Output Settings", padding=5)
        output_frame.pack(fill=tk.X, pady=5)

        output_row1 = ttk.Frame(output_frame)
        output_row1.pack(fill=tk.X, pady=2)

        ttk.Label(output_row1, text="Output Prefix:").pack(side=tk.LEFT, padx=(0, 5))
        self.prefix_var = tk.StringVar(value="physics_problem")
        ttk.Entry(output_row1, textvariable=self.prefix_var, width=15).pack(side=tk.LEFT, padx=(0, 10))

        self.generate_diagrams_var = tk.BooleanVar(value=MANIM_AVAILABLE)
        ttk.Checkbutton(output_row1, text="Generate Diagrams",
                       variable=self.generate_diagrams_var).pack(side=tk.LEFT, padx=(0, 10))

        self.save_json_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(output_row1, text="Save JSON Files",
                       variable=self.save_json_var).pack(side=tk.LEFT)

        # Preview and Generate section
        preview_frame = ttk.LabelFrame(main_frame, text="Preview & Generate", padding=10)
        preview_frame.pack(fill=tk.BOTH, expand=True)

        # Control buttons
        button_row = ttk.Frame(preview_frame)
        button_row.pack(fill=tk.X, pady=(0, 10))

        ttk.Button(button_row, text="👁️ Preview Batch",
                  command=self.preview_batch).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_row, text="⚡ Generate All",
                  command=self.generate_batch).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_row, text="📁 Open Output Folder",
                  command=self.open_output_folder).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_row, text="🛑 Stop Generation",
                  command=self.stop_batch).pack(side=tk.LEFT)

        # Create notebook for preview and log
        preview_notebook = ttk.Notebook(preview_frame)
        preview_notebook.pack(fill=tk.BOTH, expand=True)

        # Preview tab
        preview_tab = ttk.Frame(preview_notebook)
        preview_notebook.add(preview_tab, text="Preview")

        self.preview_text = scrolledtext.ScrolledText(preview_tab, height=12, font=("Consolas", 9), bg="#f8f9fa")
        self.preview_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Progress tab
        progress_tab = ttk.Frame(preview_notebook)
        preview_notebook.add(progress_tab, text="Progress")

        self.batch_log_text = scrolledtext.ScrolledText(progress_tab, height=12, font=("Consolas", 9), bg="#f0f0f0")
        self.batch_log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Initialize batch control
        self.batch_stop_flag = False

    def create_settings_tab(self):
        """Create Tab 5: Settings and configuration."""
        self.tab5 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab5, text="⚙️ Settings")

        main_frame = ttk.Frame(self.tab5)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # System info
        system_frame = ttk.LabelFrame(main_frame, text="System Information", padding=10)
        system_frame.pack(fill=tk.X, pady=(0, 10))

        system_info = f"""
Python Version: {self.get_python_version()}
Operating System: {self.get_os_info()}
Tkinter Version: {tk.TkVersion}
Current Directory: {Path.cwd()}
Output Directory: {self.output_directory}

Dependencies Status:
• Clipboard (pyperclip): {'✅ Available' if CLIPBOARD_AVAILABLE else '❌ Not installed'}
• Manim: {'✅ Available' if MANIM_AVAILABLE else '❌ Not installed'}
• NumPy: {'✅ Available' if self.check_numpy() else '❌ Not installed'}
        """.strip()

        system_label = ttk.Label(system_frame, text=system_info, font=("Consolas", 9))
        system_label.pack(anchor="w")

        # Installation help
        install_frame = ttk.LabelFrame(main_frame, text="Installation Help", padding=10)
        install_frame.pack(fill=tk.X, pady=(0, 10))

        install_text = """
To install missing dependencies on Windows:

pip install pyperclip manim numpy

For Manim (diagram generation):
1. Install Python 3.8+ (already done)
2. pip install manim
3. May require additional system dependencies

For better performance, also consider:
pip install pillow matplotlib
        """.strip()

        ttk.Label(install_frame, text=install_text, font=("Consolas", 9)).pack(anchor="w")

        # Settings controls
        controls_frame = ttk.LabelFrame(main_frame, text="Application Settings", padding=10)
        controls_frame.pack(fill=tk.X)

        ttk.Button(controls_frame, text="🔄 Refresh System Info",
                  command=self.refresh_settings).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(controls_frame, text="📁 Change Output Directory",
                  command=self.set_output_directory).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(controls_frame, text="🧹 Clear All Logs",
                  command=self.clear_all_logs).pack(side=tk.LEFT)

    def create_parameter_inputs(self, parent):
        """Create organized parameter input controls."""
        # Angle parameters
        angle_frame = ttk.Frame(parent)
        angle_frame.pack(fill=tk.X, pady=2)

        ttk.Label(angle_frame, text="Angles:", width=8).pack(side=tk.LEFT, padx=(0, 5))
        self.angle_start_var = tk.StringVar(value="15")
        ttk.Entry(angle_frame, textvariable=self.angle_start_var, width=6).pack(side=tk.LEFT, padx=2)
        ttk.Label(angle_frame, text="to").pack(side=tk.LEFT, padx=2)
        self.angle_end_var = tk.StringVar(value="75")
        ttk.Entry(angle_frame, textvariable=self.angle_end_var, width=6).pack(side=tk.LEFT, padx=2)
        ttk.Label(angle_frame, text="step").pack(side=tk.LEFT, padx=2)
        self.angle_step_var = tk.StringVar(value="15")
        ttk.Entry(angle_frame, textvariable=self.angle_step_var, width=6).pack(side=tk.LEFT, padx=2)
        ttk.Label(angle_frame, text="degrees").pack(side=tk.LEFT, padx=2)

        # Mass parameters
        mass_frame = ttk.Frame(parent)
        mass_frame.pack(fill=tk.X, pady=2)

        ttk.Label(mass_frame, text="Masses:", width=8).pack(side=tk.LEFT, padx=(0, 5))
        self.mass_values_var = tk.StringVar(value="1.0, 2.0, 5.0")
        ttk.Entry(mass_frame, textvariable=self.mass_values_var, width=25).pack(side=tk.LEFT, padx=2)
        ttk.Label(mass_frame, text="kg (comma-separated)").pack(side=tk.LEFT, padx=2)

        # Length parameters
        length_frame = ttk.Frame(parent)
        length_frame.pack(fill=tk.X, pady=2)

        ttk.Label(length_frame, text="Lengths:", width=8).pack(side=tk.LEFT, padx=(0, 5))
        self.length_values_var = tk.StringVar(value="3.0, 4.0, 5.0")
        ttk.Entry(length_frame, textvariable=self.length_values_var, width=25).pack(side=tk.LEFT, padx=2)
        ttk.Label(length_frame, text="units (comma-separated)").pack(side=tk.LEFT, padx=2)

    def create_log_area(self):
        """Create the activity log area."""
        log_frame = ttk.LabelFrame(self.root, text="Activity Log", padding=5)
        log_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

        # Log controls
        log_controls = ttk.Frame(log_frame)
        log_controls.pack(fill=tk.X, pady=(0, 5))

        ttk.Button(log_controls, text="🧹 Clear Log",
                  command=self.clear_log).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(log_controls, text="💾 Save Log",
                  command=self.save_log).pack(side=tk.LEFT)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=6, font=("Consolas", 9), bg="#f0f0f0")
        self.log_text.pack(fill=tk.X)

    # Enhanced utility methods
    def load_sample(self):
        """Load selected sample problem."""
        sample = self.sample_var.get()
        if sample:
            self.problem_text.delete(1.0, tk.END)
            self.problem_text.insert(tk.END, sample)
            self.log_message("📝 Sample problem loaded")

    def clear_prompt(self):
        """Clear the generated prompt."""
        self.output_text.delete(1.0, tk.END)
        self.log_message("🔄 Prompt cleared")

    def load_json_file(self):
        """Load JSON from file."""
        file_path = filedialog.askopenfilename(
            title="Select JSON file",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialdir=self.output_directory
        )

        if file_path:
            try:
                with open(file_path, 'r') as f:
                    json_content = f.read()
                    self.json_text.delete(1.0, tk.END)
                    self.json_text.insert(tk.END, json_content)
                    self.log_message(f"📁 Loaded JSON from {Path(file_path).name}")
                    self.validate_json()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load JSON file:\n{str(e)}")

    def save_json_as(self):
        """Save JSON with file dialog."""
        json_content = self.json_text.get(1.0, tk.END).strip()
        if not json_content:
            messagebox.showwarning("Warning", "No JSON to save!")
            return

        file_path = filedialog.asksaveasfilename(
            title="Save JSON file",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialdir=self.output_directory
        )

        if file_path:
            try:
                # Validate and format JSON
                data = json.loads(json_content)
                with open(file_path, 'w') as f:
                    json.dump(data, f, indent=2)
                self.log_message(f"💾 JSON saved as {Path(file_path).name}")
                messagebox.showinfo("Success", f"JSON saved successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save JSON:\n{str(e)}")

    def save_3d_prompt(self):
        """Save 3D prompt to file."""
        prompt = self.prompt_3d_text.get(1.0, tk.END).strip()
        if not prompt:
            messagebox.showwarning("Warning", "No 3D prompt to save!")
            return

        file_path = filedialog.asksaveasfilename(
            title="Save 3D prompt",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialdir=self.output_directory
        )

        if file_path:
            try:
                with open(file_path, 'w') as f:
                    f.write(prompt)
                self.log_message(f"💾 3D prompt saved as {Path(file_path).name}")
                messagebox.showinfo("Success", "3D prompt saved successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save prompt:\n{str(e)}")

    def set_output_directory(self):
        """Set output directory."""
        directory = filedialog.askdirectory(
            title="Select output directory",
            initialdir=self.output_directory
        )

        if directory:
            self.output_directory = Path(directory)
            self.log_message(f"📁 Output directory set to {self.output_directory}")
            messagebox.showinfo("Success", f"Output directory updated:\n{self.output_directory}")

    def stop_batch(self):
        """Stop batch processing."""
        self.batch_stop_flag = True
        self.log_message("🛑 Batch processing stop requested")

    def show_about(self):
        """Show about dialog."""
        about_text = """
Physics Diagram Generator
Enhanced Version

A comprehensive tool for converting physics problems into visual diagrams.

Features:
• Text to JSON conversion via ChatGPT
• Automatic diagram generation with Manim
• 3D image prompt generation
• Batch processing capabilities
• Enhanced user interface

Created for educational purposes.
        """.strip()

        messagebox.showinfo("About", about_text)

    def get_python_version(self):
        """Get Python version info."""
        import sys
        return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

    def get_os_info(self):
        """Get OS information."""
        import platform
        return f"{platform.system()} {platform.release()}"

    def check_numpy(self):
        """Check if NumPy is available."""
        try:
            import numpy
            return True
        except ImportError:
            return False

    def refresh_settings(self):
        """Refresh settings tab information."""
        # Remove and recreate settings tab
        self.notebook.forget(self.tab5)
        self.create_settings_tab()
        self.log_message("🔄 Settings refreshed")

    def clear_all_logs(self):
        """Clear all log areas."""
        self.log_text.delete(1.0, tk.END)
        self.batch_log_text.delete(1.0, tk.END)
        self.preview_text.delete(1.0, tk.END)
        self.log_message("🧹 All logs cleared")

    def clear_log(self):
        """Clear activity log."""
        self.log_text.delete(1.0, tk.END)
        self.log_message("🧹 Activity log cleared")

    def save_log(self):
        """Save activity log to file."""
        log_content = self.log_text.get(1.0, tk.END).strip()
        if not log_content:
            messagebox.showwarning("Warning", "No log content to save!")
            return

        file_path = filedialog.asksaveasfilename(
            title="Save activity log",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialdir=self.output_directory
        )

        if file_path:
            try:
                with open(file_path, 'w') as f:
                    f.write(log_content)
                self.log_message(f"💾 Log saved as {Path(file_path).name}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save log:\n{str(e)}")

    def log_message(self, message):
        """Enhanced logging with timestamps."""
        from datetime import datetime
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.root.update_idletasks()

    def log_initial_status(self):
        """Log initial status messages."""
        self.log_message("🚀 Physics Diagram Generator - Enhanced Version")
        self.log_message("=" * 50)

        if CLIPBOARD_AVAILABLE:
            self.log_message("✅ Clipboard support available")
        else:
            self.log_message("⚠️ Clipboard not available - install pyperclip for copy functionality")

        if MANIM_AVAILABLE:
            self.log_message("✅ Manim available - can generate diagrams!")
        else:
            self.log_message("⚠️ Manim not available - install manim for diagram generation")

        self.log_message(f"📁 Output directory: {self.output_directory}")
        self.log_message("🚀 Ready! Follow the tabs: Text → JSON → Diagram/3D Prompt")

    # Keep all existing methods with enhanced error handling and logging
    def generate_prompt(self):
        """Generate ChatGPT prompt for text to JSON conversion."""
        problem_text = self.problem_text.get(1.0, tk.END).strip()

        if not problem_text:
            messagebox.showwarning("Warning", "Please enter a physics problem first.")
            return

        try:
            prompt = f"""I have a physics word problem that I need converted to JSON format for a diagram generator.

PROBLEM:
{problem_text}

INSTRUCTIONS:
Convert this problem into JSON format following this schema:

For incline plane problems:
{{
  "scene_type": "incline_plane",
  "objects": [
    {{"type": "incline", "angle": NUMBER, "length": NUMBER, "base": [NUMBER, NUMBER]}},
    {{"type": "block", "position": [NUMBER, NUMBER], "on": "incline"}}
  ],
  "forces": [
    {{"type": "gravity", "on": "block", "direction": "down"}},
    {{"type": "normal", "on": "block", "direction": "perpendicular_to_incline"}}
  ]
}}

For pulley-incline problems:
{{
  "scene_type": "pulley_incline",
  "objects": [
    {{"type": "incline", "angle": NUMBER, "length": NUMBER, "base": [NUMBER, NUMBER]}},
    {{"type": "block", "position": [NUMBER, NUMBER], "on": "incline"}},
    {{"type": "block", "position": [NUMBER, NUMBER], "on": "pulley"}}
  ],
  "pulley_radius": NUMBER,
  "rope_length": NUMBER
}}

Rules:
- Output ONLY the JSON, no explanation
- Use degrees for angles, default length 5.0
- Position as [x, y] coordinates

Please convert this problem into the appropriate JSON format."""

            self.output_text.delete(1.0, tk.END)
            self.output_text.insert(tk.END, prompt)
            self.log_message("✅ ChatGPT prompt generated successfully")

        except Exception as e:
            self.log_message(f"❌ Error generating prompt: {str(e)}")
            messagebox.showerror("Error", f"Failed to generate prompt:\n{str(e)}")

    def copy_prompt(self):
        """Copy ChatGPT prompt to clipboard."""
        prompt = self.output_text.get(1.0, tk.END).strip()
        if not prompt:
            messagebox.showwarning("Warning", "No prompt to copy. Generate one first!")
            return

        if CLIPBOARD_AVAILABLE:
            try:
                pyperclip.copy(prompt)
                self.log_message("📋 Prompt copied to clipboard successfully")
                messagebox.showinfo("Success", "Prompt copied to clipboard!")
            except Exception as e:
                self.log_message(f"❌ Clipboard error: {str(e)}")
                messagebox.showerror("Error", f"Failed to copy to clipboard:\n{str(e)}")
        else:
            messagebox.showinfo("Copy Manually",
                              "Clipboard not available. Please select all text and copy manually (Ctrl+A, Ctrl+C)")

    def open_chatgpt(self):
        """Open ChatGPT in browser."""
        try:
            webbrowser.open("https://chat.openai.com")
            self.log_message("🌐 Opened ChatGPT in browser")
        except Exception as e:
            self.log_message(f"❌ Browser error: {str(e)}")
            messagebox.showerror("Error", f"Failed to open browser:\n{str(e)}")

    def validate_json(self):
        """Validate the JSON input with enhanced error reporting."""
        json_content = self.json_text.get(1.0, tk.END).strip()
        if not json_content:
            messagebox.showwarning("Warning", "Please paste JSON first!")
            return False

        try:
            self.current_json = json.loads(json_content)

            # Enhanced validation
            required_fields = ["scene_type", "objects"]
            for field in required_fields:
                if field not in self.current_json:
                    raise ValueError(f"Missing required field: {field}")

            # Validate scene type
            valid_scene_types = ["incline_plane", "pulley_incline", "friction_incline"]
            if self.current_json.get("scene_type") not in valid_scene_types:
                self.log_message(f"⚠️ Unknown scene type: {self.current_json.get('scene_type')}")

            # Validate objects
            objects = self.current_json.get("objects", [])
            if not objects:
                raise ValueError("No objects found in JSON")

            self.log_message("✅ JSON validation passed - structure is valid")
            messagebox.showinfo("Success", "✅ JSON is valid and ready for processing!")
            return True

        except json.JSONDecodeError as e:
            error_msg = f"Invalid JSON format: {str(e)}"
            self.log_message(f"❌ JSON parsing error: {error_msg}")
            messagebox.showerror("JSON Error", error_msg)
            return False
        except Exception as e:
            error_msg = f"JSON validation failed: {str(e)}"
            self.log_message(f"❌ Validation error: {error_msg}")
            messagebox.showerror("Validation Error", error_msg)
            return False

    def save_json(self):
        """Save current JSON to file with enhanced error handling."""
        json_content = self.json_text.get(1.0, tk.END).strip()
        if not json_content:
            messagebox.showwarning("Warning", "No JSON to save!")
            return

        try:
            # Validate before saving
            data = json.loads(json_content)

            # Generate filename with timestamp
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = self.output_directory / f"physics_problem_{timestamp}.json"

            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)

            self.log_message(f"💾 JSON saved successfully as {filename.name}")
            messagebox.showinfo("Success", f"JSON saved as:\n{filename}")

        except json.JSONDecodeError as e:
            error_msg = f"Invalid JSON format: {str(e)}"
            self.log_message(f"❌ Save failed - {error_msg}")
            messagebox.showerror("JSON Error", error_msg)
        except Exception as e:
            error_msg = f"Failed to save JSON: {str(e)}"
            self.log_message(f"❌ Save error: {error_msg}")
            messagebox.showerror("Error", error_msg)

    def generate_manim_diagram(self):
        """Generate Manim diagram from JSON with progress tracking."""
        if not hasattr(self, 'current_json') or not self.current_json:
            if not self.validate_json():
                return

        if not MANIM_AVAILABLE:
            messagebox.showerror("Manim Not Available",
                               "Manim is not installed.\n\nInstall with: pip install manim")
            return

        # Show progress
        self.progress_bar.pack(fill=tk.X, pady=5)
        self.progress_label.pack()
        self.progress_bar.start(10)
        self.progress_label.config(text="Generating Manim diagram...")

        self.log_message("🎬 Starting Manim diagram generation...")

        def generate_thread():
            try:
                class SimplePhysicsScene(Scene):
                    def __init__(self, json_data, **kwargs):
                        super().__init__(**kwargs)
                        self.json_data = json_data

                    def construct(self):
                        self.camera.background_color = WHITE

                        objects = self.json_data.get("objects", [])
                        incline_obj = next((obj for obj in objects if obj["type"] == "incline"), None)
                        if not incline_obj:
                            return

                        angle = incline_obj["angle"]
                        length = incline_obj.get("length", 5.0)
                        base = incline_obj.get("base", [0, 0])

                        # Create incline
                        angle_rad = math.radians(angle)
                        start_point = np.array([base[0] - 2, base[1], 0])
                        end_point = np.array([
                            start_point[0] + length * math.cos(angle_rad),
                            start_point[1] + length * math.sin(angle_rad), 0
                        ])

                        incline_line = Line(start_point, end_point, stroke_width=8, color=BLUE)
                        base_line = Line(start_point, np.array([end_point[0], start_point[1], 0]),
                                       stroke_width=4, color=GRAY)

                        angle_arc = Arc(radius=0.8, start_angle=0, angle=angle_rad, color=GREEN)
                        angle_arc.move_arc_center_to(start_point)

                        angle_label = Text(f"{angle}°", font_size=24, color=GREEN)
                        angle_label.next_to(angle_arc, RIGHT, buff=0.2)

                        # Create block
                        distance_along = length * 0.6
                        actual_x = start_point[0] + distance_along * math.cos(angle_rad)
                        actual_y = start_point[1] + distance_along * math.sin(angle_rad)

                        offset_distance = 0.3
                        offset_x = -offset_distance * math.sin(angle_rad)
                        offset_y = offset_distance * math.cos(angle_rad)

                        block_pos = np.array([actual_x + offset_x, actual_y + offset_y, 0])
                        block = Square(side_length=0.5, fill_color=RED, fill_opacity=0.8, stroke_color=RED_D)
                        block.move_to(block_pos)
                        block.rotate(angle_rad)

                        mass_label = Text("m", font_size=18, color=WHITE)
                        mass_label.move_to(block_pos)

                        # Forces
                        forces = self.json_data.get("forces", [])
                        force_objects = []

                        for force in forces:
                            if force.get("on") == "block":
                                if force.get("direction") == "down":
                                    gravity_arrow = Arrow(start=block_pos, end=block_pos + DOWN * 1.5,
                                                        color=YELLOW, stroke_width=6, tip_length=0.3)
                                    gravity_label = Text("mg", font_size=16, color=YELLOW)
                                    gravity_label.next_to(gravity_arrow.get_end(), DOWN, buff=0.1)
                                    force_objects.extend([gravity_arrow, gravity_label])

                                elif force.get("direction") == "perpendicular_to_incline":
                                    normal_angle = angle_rad + math.pi/2
                                    normal_vector = np.array([math.cos(normal_angle), math.sin(normal_angle), 0])

                                    normal_arrow = Arrow(start=block_pos, end=block_pos + normal_vector * 1.5,
                                                       color=PURPLE, stroke_width=6, tip_length=0.3)
                                    normal_label = Text("N", font_size=16, color=PURPLE)
                                    normal_label.next_to(normal_arrow.get_end(), normal_vector * 0.5)
                                    force_objects.extend([normal_arrow, normal_label])

                        # Title and info
                        title = Text("Physics Diagram", font_size=32, color=BLACK)
                        title.to_edge(UP, buff=0.5)

                        info_text = Text(f"Angle: {angle}°, Length: {length} units", font_size=16, color=BLACK)
                        info_text.to_edge(DOWN, buff=0.5)

                        # Add all elements
                        self.add(incline_line, base_line, angle_arc, angle_label)
                        self.add(block, mass_label)
                        self.add(*force_objects)
                        self.add(title, info_text)

                # Configure and render
                config.pixel_height = 720
                config.pixel_width = 1280
                config.frame_rate = 15
                config.background_color = WHITE

                # Generate unique filename
                from datetime import datetime
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_filename = self.output_directory / f"physics_diagram_{timestamp}"
                config.output_file = str(output_filename)

                scene = SimplePhysicsScene(self.current_json)
                scene.render()

                # Update UI on success
                def on_success():
                    self.progress_bar.stop()
                    self.progress_bar.pack_forget()
                    self.progress_label.pack_forget()
                    self.log_message(f"✅ Diagram generated successfully: {output_filename.name}.mp4")
                    messagebox.showinfo("Success", f"Diagram generated successfully!\n\nSaved as: {output_filename.name}.mp4\nLocation: {self.output_directory}")

                self.root.after(0, on_success)

            except Exception as e:
                def on_error():
                    self.progress_bar.stop()
                    self.progress_bar.pack_forget()
                    self.progress_label.pack_forget()
                    error_msg = f"Diagram generation failed: {str(e)}"
                    self.log_message(f"❌ {error_msg}")
                    messagebox.showerror("Generation Error", error_msg)

                self.root.after(0, on_error)

        # Start generation in separate thread
        threading.Thread(target=generate_thread, daemon=True).start()

    def generate_3d_prompt(self):
        """Generate 3D image prompt based on current JSON with enhanced formatting."""
        if not hasattr(self, 'current_json') or not self.current_json:
            messagebox.showwarning("Warning", "Please validate JSON first.")
            return

        try:
            objects = self.current_json.get("objects", [])
            incline = next((obj for obj in objects if obj["type"] == "incline"), None)

            if not incline:
                messagebox.showerror("Error", "No incline found in JSON!")
                return

            angle = incline.get("angle", 30)
            length = incline.get("length", 5.0)
            scene_type = self.current_json.get("scene_type", "incline_plane")

            # Enhanced scene description based on type
            if scene_type == "pulley_incline":
                scene_desc = f"a pulley-incline system with a wooden ramp at {angle}° connected to a pulley system"
            elif scene_type == "friction_incline":
                scene_desc = f"a friction incline experiment with a textured ramp at {angle}° showing friction forces"
            else:
                scene_desc = f"an inclined plane experiment with a wooden ramp at {angle}°"

            prompt_3d = f"""Create a photorealistic 3D rendered physics diagram showing {scene_desc}.

SCENE SETUP:
- A solid wooden inclined plane ramp at exactly {angle}° angle, {length} units long
- Beautiful oak wood texture with visible grain and subtle satin finish
- A metallic red/orange cube (representing mass "m") positioned on the incline surface
- Clean horizontal gray reference surface/table underneath for context
- Professional educational laboratory setting

PHYSICS ELEMENTS:
- PURPLE arrow labeled "N" pointing perpendicular to incline surface (normal force)
- YELLOW arrow labeled "mg" pointing straight down from the block (gravitational force)
- Clear "{angle}°" angle marking at the base with green color
- All force vectors should be bold, clearly visible, and professionally rendered
- The block positioned approximately {int(length * 0.6)} units up the ramp

VISUAL QUALITY:
- Photorealistic 3D rendering with studio-quality lighting
- Soft directional lighting with subtle shadows
- Clean, educational textbook aesthetic
- Neutral background (light gray or white gradient)
- Sharp focus throughout with slight depth of field
- Camera angle: slightly elevated 3/4 view showing dimensionality clearly

MATERIALS & TEXTURES:
- Wood: Natural oak with prominent grain, slight satin finish, warm brown tones
- Block: Brushed aluminum or painted metal with subtle reflectivity
- Force arrows: Clean, bold colors with slight luminous glow effect
- Text labels: Clean sans-serif font, slightly raised/embossed appearance
- Surface: Matte gray with subtle texture

COMPOSITION:
- Well-balanced composition with the incline as focal point
- Adequate white space around the diagram
- Professional physics education aesthetic
- Render quality suitable for textbook or presentation use

Style: High-end 3D visualization, educational physics illustration, photorealistic rendering"""

            self.prompt_3d_text.delete(1.0, tk.END)
            self.prompt_3d_text.insert(tk.END, prompt_3d)
            self.log_message(f"🎨 Enhanced 3D prompt generated for {scene_type} at {angle}°")

        except Exception as e:
            error_msg = f"Failed to generate 3D prompt: {str(e)}"
            self.log_message(f"❌ {error_msg}")
            messagebox.showerror("Error", error_msg)

    def copy_3d_prompt(self):
        """Copy 3D prompt to clipboard with enhanced error handling."""
        prompt = self.prompt_3d_text.get(1.0, tk.END).strip()
        if not prompt:
            messagebox.showwarning("Warning", "No 3D prompt to copy. Generate one first!")
            return

        if CLIPBOARD_AVAILABLE:
            try:
                pyperclip.copy(prompt)
                self.log_message("📋 3D prompt copied to clipboard successfully")
                messagebox.showinfo("Success", "3D prompt copied to clipboard!")
            except Exception as e:
                self.log_message(f"❌ Clipboard error: {str(e)}")
                messagebox.showerror("Error", f"Failed to copy to clipboard:\n{str(e)}")
        else:
            messagebox.showinfo("Copy Manually",
                              "Clipboard not available. Please select all text and copy manually (Ctrl+A, Ctrl+C)")

    def open_output_folder(self):
        """Open the output folder with enhanced error handling."""
        try:
            if os.name == 'nt':  # Windows
                os.startfile(str(self.output_directory))
            elif os.name == 'posix':  # macOS and Linux
                os.system(f'open "{self.output_directory}"' if sys.platform == 'darwin'
                         else f'xdg-open "{self.output_directory}"')
            self.log_message(f"📁 Opened output directory: {self.output_directory}")
        except Exception as e:
            self.log_message(f"⚠️ Could not open folder automatically: {str(e)}")
            messagebox.showinfo("Output Location",
                              f"Generated files are located in:\n{self.output_directory}")

    def preview_batch(self):
        """Preview what will be generated in batch with enhanced formatting."""
        try:
            # Get parameters
            angle_start = int(self.angle_start_var.get())
            angle_end = int(self.angle_end_var.get())
            angle_step = int(self.angle_step_var.get())

            angles = list(range(angle_start, angle_end + 1, angle_step))
            masses = [float(m.strip()) for m in self.mass_values_var.get().split(',')]
            lengths = [float(l.strip()) for l in self.length_values_var.get().split(',')]

            template = self.batch_template_var.get()
            prefix = self.prefix_var.get()

            # Generate preview
            self.preview_text.delete(1.0, tk.END)
            self.preview_text.insert(tk.END, f"BATCH PREVIEW - {template.upper().replace('_', ' ')}\n")
            self.preview_text.insert(tk.END, "=" * 60 + "\n\n")

            # Parameters summary
            self.preview_text.insert(tk.END, f"Template: {template}\n")
            self.preview_text.insert(tk.END, f"Prefix: {prefix}\n")
            self.preview_text.insert(tk.END, f"Angles: {angles} (degrees)\n")
            self.preview_text.insert(tk.END, f"Masses: {masses} (kg)\n")
            self.preview_text.insert(tk.END, f"Lengths: {lengths} (units)\n")
            self.preview_text.insert(tk.END, f"Output Directory: {self.output_directory}\n\n")

            # Generate list
            self.preview_text.insert(tk.END, "FILES TO BE GENERATED:\n")
            self.preview_text.insert(tk.END, "-" * 30 + "\n")

            count = 0
            for angle in angles:
                for mass in masses:
                    for length in lengths:
                        count += 1
                        filename = f"{prefix}_{angle}deg_{mass}kg_{length}len"
                        self.preview_text.insert(tk.END, f"{count:3d}. {filename}\n")

                        # Show details for first few entries
                        if count <= 5:
                            self.preview_text.insert(tk.END, f"     Angle: {angle}°, Mass: {mass}kg, Length: {length} units\n")

            if count > 5:
                self.preview_text.insert(tk.END, f"     ... and {count - 5} more variations\n")

            # Summary
            self.preview_text.insert(tk.END, f"\nSUMMARY:\n")
            self.preview_text.insert(tk.END, f"Total problems: {count}\n")

            if self.generate_diagrams_var.get() and MANIM_AVAILABLE:
                self.preview_text.insert(tk.END, f"✅ Will generate {count} Manim diagrams (.mp4)\n")
            elif self.generate_diagrams_var.get():
                self.preview_text.insert(tk.END, f"⚠️ Manim not available - diagrams will be skipped\n")

            if self.save_json_var.get():
                self.preview_text.insert(tk.END, f"✅ Will save {count} JSON files\n")

            # Estimates
            estimated_time = count * 10 if MANIM_AVAILABLE and self.generate_diagrams_var.get() else count * 0.5
            self.preview_text.insert(tk.END, f"Estimated time: {estimated_time:.1f} seconds\n")

            self.log_message(f"👁️ Batch preview generated: {count} problems")

        except Exception as e:
            self.preview_text.delete(1.0, tk.END)
            error_msg = f"Preview generation failed: {str(e)}"
            self.preview_text.insert(tk.END, f"❌ {error_msg}\n")
            self.log_message(f"❌ {error_msg}")

    def generate_batch(self):
        """Generate all problems in batch with enhanced progress tracking."""
        if not MANIM_AVAILABLE and self.generate_diagrams_var.get():
            if not messagebox.askyesno("Manim Not Available",
                                     "Manim is not installed. Continue with JSON files only?"):
                return

        try:
            # Get parameters
            angle_start = int(self.angle_start_var.get())
            angle_end = int(self.angle_end_var.get())
            angle_step = int(self.angle_step_var.get())

            angles = list(range(angle_start, angle_end + 1, angle_step))
            masses = [float(m.strip()) for m in self.mass_values_var.get().split(',')]
            lengths = [float(l.strip()) for l in self.length_values_var.get().split(',')]

            template = self.batch_template_var.get()
            prefix = self.prefix_var.get()

            # Create output directory
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            batch_dir = self.output_directory / f"batch_{template}_{timestamp}"
            batch_dir.mkdir(exist_ok=True)

            # Initialize batch log
            self.batch_log_text.delete(1.0, tk.END)
            self.batch_log_text.insert(tk.END, f"🚀 BATCH GENERATION STARTED\n")
            self.batch_log_text.insert(tk.END, f"{'='*50}\n")
            self.batch_log_text.insert(tk.END, f"Template: {template}\n")
            self.batch_log_text.insert(tk.END, f"Output Directory: {batch_dir}\n")
            self.batch_log_text.insert(tk.END, f"Timestamp: {timestamp}\n\n")

            # Reset stop flag
            self.batch_stop_flag = False

            def batch_worker():
                total_count = len(angles) * len(masses) * len(lengths)
                current_count = 0
                success_count = 0
                error_count = 0

                start_time = datetime.now()

                for angle in angles:
                    if self.batch_stop_flag:
                        break

                    for mass in masses:
                        if self.batch_stop_flag:
                            break

                        for length in lengths:
                            if self.batch_stop_flag:
                                break

                            current_count += 1
                            filename = f"{prefix}_{angle}deg_{mass}kg_{length}len"

                            # Update progress
                            progress_msg = f"[{current_count}/{total_count}] Processing {filename}..."
                            self.root.after(0, lambda msg=progress_msg: self.batch_log_text.insert(tk.END, f"{msg}\n"))

                            try:
                                # Generate JSON based on template
                                if template == "incline_plane":
                                    problem_json = {
                                        "scene_type": "incline_plane",
                                        "objects": [
                                            {"type": "incline", "angle": angle, "length": length, "base": [0, 0]},
                                            {"type": "block", "position": [length/2, 0], "on": "incline", "mass": mass}
                                        ],
                                        "forces": [
                                            {"type": "gravity", "on": "block", "direction": "down"},
                                            {"type": "normal", "on": "block", "direction": "perpendicular_to_incline"}
                                        ],
                                        "parameters": {
                                            "angle_degrees": angle,
                                            "length_units": length,
                                            "mass_kg": mass
                                        }
                                    }
                                elif template == "friction_incline":
                                    problem_json = {
                                        "scene_type": "friction_incline",
                                        "objects": [
                                            {"type": "incline", "angle": angle, "length": length, "base": [0, 0]},
                                            {"type": "block", "position": [length/2, 0], "on": "incline", "mass": mass}
                                        ],
                                        "forces": [
                                            {"type": "gravity", "on": "block", "direction": "down"},
                                            {"type": "normal", "on": "block", "direction": "perpendicular_to_incline"},
                                            {"type": "friction", "on": "block", "direction": "up_incline"}
                                        ],
                                        "parameters": {
                                            "angle_degrees": angle,
                                            "length_units": length,
                                            "mass_kg": mass,
                                            "friction_coefficient": 0.3
                                        }
                                    }

                                # Save JSON if requested
                                if self.save_json_var.get():
                                    json_path = batch_dir / f"{filename}.json"
                                    with open(json_path, 'w') as f:
                                        json.dump(problem_json, f, indent=2)

                                success_count += 1
                                self.root.after(0, lambda: self.batch_log_text.insert(tk.END, f"✅ {filename} completed successfully\n"))

                            except Exception as e:
                                error_count += 1
                                error_msg = f"❌ {filename} failed: {str(e)}"
                                self.root.after(0, lambda msg=error_msg: self.batch_log_text.insert(tk.END, f"{msg}\n"))

                            # Update progress in log
                            if current_count % 5 == 0:  # Every 5 items
                                elapsed = (datetime.now() - start_time).total_seconds()
                                rate = current_count / elapsed if elapsed > 0 else 0
                                eta = (total_count - current_count) / rate if rate > 0 else 0

                                progress_update = f"Progress: {current_count}/{total_count} ({current_count/total_count*100:.1f}%) - ETA: {eta:.1f}s\n"
                                self.root.after(0, lambda msg=progress_update: self.batch_log_text.insert(tk.END, msg))

                # Final summary
                def on_complete():
                    elapsed = (datetime.now() - start_time).total_seconds()

                    if self.batch_stop_flag:
                        self.batch_log_text.insert(tk.END, f"\n🛑 BATCH GENERATION STOPPED BY USER\n")
                    else:
                        self.batch_log_text.insert(tk.END, f"\n🎉 BATCH GENERATION COMPLETED!\n")

                    self.batch_log_text.insert(tk.END, f"{'='*50}\n")
                    self.batch_log_text.insert(tk.END, f"Total processed: {current_count}/{total_count}\n")
                    self.batch_log_text.insert(tk.END, f"Successful: {success_count}\n")
                    self.batch_log_text.insert(tk.END, f"Errors: {error_count}\n")
                    self.batch_log_text.insert(tk.END, f"Time elapsed: {elapsed:.1f} seconds\n")
                    self.batch_log_text.insert(tk.END, f"Output location: {batch_dir}\n")

                    if not self.batch_stop_flag:
                        messagebox.showinfo("Batch Complete",
                            f"Generated {success_count} problems successfully!\n"
                            f"Errors: {error_count}\n"
                            f"Time: {elapsed:.1f} seconds\n\n"
                            f"Check folder: {batch_dir.name}")

                self.root.after(0, on_complete)

            # Start batch processing
            self.log_message(f"⚡ Starting batch generation: {len(angles) * len(masses) * len(lengths)} problems")
            threading.Thread(target=batch_worker, daemon=True).start()

        except Exception as e:
            error_msg = f"Batch generation setup failed: {str(e)}"
            self.batch_log_text.insert(tk.END, f"❌ {error_msg}\n")
            self.log_message(f"❌ {error_msg}")
            messagebox.showerror("Batch Error", error_msg)

    def run(self):
        """Run the GUI application with enhanced error handling."""
        try:
            self.log_message("🎬 Starting Physics Diagram Generator GUI...")
            self.root.mainloop()
        except Exception as e:
            error_msg = f"Application error: {str(e)}"
            self.log_message(f"❌ {error_msg}")
            messagebox.showerror("Application Error", error_msg)
        finally:
            self.log_message("👋 Application closed")

# Enhanced main execution
if __name__ == "__main__":
    try:
        app = PhysicsGUI()
        app.run()
    except Exception as e:
        print(f"Failed to start application: {e}")
        input("Press Enter to exit...")