this is thursday mornings version of vectordraw4.1 it works quite well but has some bugs stil around the different types of problems, for example the pully problem dosnt work well.

python run.py will open a gui