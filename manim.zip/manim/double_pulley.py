from manim import *

class DoublePulleyDiagram(Scene):
    def construct(self):
        # -- Pulley Positions --
        pulley_left = LEFT * 3 + UP * 2
        pulley_right = RIGHT * 3 + UP * 2

        # -- Pulleys --
        pulley_radius = 0.3
        pulley1 = Circle(radius=pulley_radius, color=GREY).move_to(pulley_left)
        pulley2 = Circle(radius=pulley_radius, color=GREY).move_to(pulley_right)

        # -- Masses --
        mass_a = Square(0.6, color=RED, fill_opacity=1).move_to(LEFT * 3 + DOWN * 1)
        mass_b = Square(0.6, color=BLUE, fill_opacity=1).move_to(RIGHT * 3 + DOWN * 2)

        # -- Ropes --
        rope_left = Line(start=pulley_left, end=mass_a.get_top(), color=WHITE)
        rope_right = Line(start=pulley_right, end=mass_b.get_top(), color=WHITE)
        rope_between = Line(start=pulley_left + RIGHT * pulley_radius,
                            end=pulley_right + LEFT * pulley_radius, color=WHITE)

        # -- Ceiling bar --
        ceiling = Line(start=LEFT * 4, end=RIGHT * 4, color=WHITE).shift(UP * 2.5)

        # -- Force Arrows --
        g_a = Arrow(start=mass_a.get_bottom(), end=mass_a.get_bottom() + DOWN * 1,
                    buff=0, color=YELLOW)
        g_b = Arrow(start=mass_b.get_bottom(), end=mass_b.get_bottom() + DOWN * 1,
                    buff=0, color=YELLOW)

        t_a = Arrow(start=mass_a.get_top(), end=mass_a.get_top() + UP * 1,
                    buff=0, color=GREEN)
        t_b = Arrow(start=mass_b.get_top(), end=mass_b.get_top() + UP * 1,
                    buff=0, color=GREEN)



        # -- Add everything --
        self.add(ceiling, pulley1, pulley2,
                 rope_left, rope_right, rope_between,
                 mass_a, mass_b,
                 g_a, g_b, t_a, t_b,
                 label_a, label_b,
                 g_label_a, g_label_b, t_label_a, t_label_b)
