import json
from manim import *

class AutoDiagram(Scene):
    def construct(self):
        with open("scene.json", "r") as f:
            scene = json.load(f)

        incline_angle = scene["incline_angle"]
        forces = scene["forces"]

        # Setup (same as before)
        axes = Axes(x_range=[0, 7], y_range=[0, 5], x_length=7, y_length=5,
                    axis_config={"include_tip": False})
        incline = Line(start=axes.c2p(1, 1), end=axes.c2p(6, 3)).set_color(GREY)
        block = Square(0.5, fill_color=RED, fill_opacity=1)
        block.rotate(-incline_angle * DEGREES)
        block.move_to(axes.c2p(3.5, 2))
        self.add(axes, incline, block)

        # Add forces if requested
        if "gravity" in forces:
            g_arrow = Arrow(start=block.get_center(),
                            end=block.get_center() + 1.2 * DOWN,
                            buff=0, color=BLUE).set_stroke(width=4)
            g_label = MathTex("mg").next_to(g_arrow, DOWN)
            self.add(g_arrow, g_label)

        if "normal" in forces:
            n_arrow = Arrow(start=block.get_center(),
                            end=block.get_center() + UP + LEFT * 0.5,
                            buff=0, color=GREEN).set_stroke(width=4)
            n_label = MathTex("N").next_to(n_arrow, LEFT)
            self.add(n_arrow, n_label)
