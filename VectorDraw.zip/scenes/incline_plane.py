from manim import *
import json
import numpy as np

class InclinePlaneScene(Scene):
    _data = None

    @classmethod
    def load_and_render(cls, json_path):
        with open(json_path) as f:
            cls._data = json.load(f)
        from manim import config, tempconfig
        with tempconfig({"quality": "low_quality", "output_file": "outputs/renders/incline1.png"}):
            scene = cls()
            scene.render()

    def construct(self):
        data = self._data
        incline = data["objects"][0]
        block = data["objects"][1]

        angle = incline["angle"]
        length = incline["length"]
        base = incline["base"]

        radians = angle * DEGREES
        x = length * np.cos(radians)
        y = length * np.sin(radians)

        incline_shape = Polygon(
            ORIGIN,
            [x, 0, 0],
            [x, y, 0],
            color=WHITE
        ).move_to(np.array(base + [0]))
        self.add(incline_shape)

        block_pos = block["position"]
        block_shape = Square(0.5, color=BLUE).move_to(np.array(block_pos + [0]))
        self.add(block_shape)

        # Add force arrows
        self.add(Arrow(start=block_shape.get_center(), end=block_shape.get_center() + DOWN, buff=0, color=YELLOW))
        self.add(Arrow(start=block_shape.get_center(), end=block_shape.get_center() + UP + LEFT, buff=0, color=GREEN))
