import json

def generate_prompt(scene_json_path, output_path):
    with open(scene_json_path) as f:
        scene_json = json.load(f)

    incline = next(o for o in scene_json["objects"] if o["type"] == "incline")
    block = next(o for o in scene_json["objects"] if o["type"] == "block")
    angle = incline["angle"]
    mass = block["mass"]

    prompt = {
        "prompt": (
            f"A realistic textbook-style diagram of a {mass} kg block resting on a {angle}° incline. "
            "Include vectors showing gravitational force straight down and a normal force perpendicular to the incline. "
            "Use clean diagram style with angle markers and simple shading."
        )
    }

    with open(output_path, "w") as out:
        json.dump(prompt, out, indent=2)

if __name__ == "__main__":
    generate_prompt("scene_data/incline1.json", "outputs/dalle_prompts/incline1.json")
