from scenes.incline_plane import InclinePlaneScene

if __name__ == "__main__":
    InclinePlaneScene.load_and_render("scene_data/incline1.json")
