#!/usr/bin/env python3
"""
Physics Diagram Generator CLI
Command-line interface for generating physics diagrams from JSON scene descriptions.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, Any

# Import the main generator (assuming it's in the same directory)
try:
    from physics_diagram_generator import PhysicsDiagramGenerator
except ImportError:
    print("❌ Error: Could not import PhysicsDiagramGenerator")
    print("Make sure physics_diagram_generator.py is in the same directory")
    sys.exit(1)


class PhysicsCLI:
    """Command-line interface for physics diagram generation."""

    def __init__(self):
        self.generator = PhysicsDiagramGenerator()

    def setup_parser(self) -> argparse.ArgumentParser:
        """Set up command-line argument parser."""
        parser = argparse.ArgumentParser(
            description="Generate physics diagrams from JSON scene descriptions",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  %(prog)s scene.json                    # Generate diagram from JSON file
  %(prog)s scene.json -o my_diagram      # Specify output name
  %(prog)s --example incline             # Generate example incline scene
  %(prog)s --example pulley              # Generate example pulley scene
  %(prog)s --validate scene.json         # Validate JSON without generating
  %(prog)s --template incline            # Print JSON template
            """
        )

        # Main arguments
        parser.add_argument(
            'input_file',
            nargs='?',
            help='JSON file containing scene description'
        )

        parser.add_argument(
            '-o', '--output',
            default='physics_diagram',
            help='Output file name (without extension)'
        )

        # Generation options
        parser.add_argument(
            '--format',
            choices=['mp4', 'gif', 'png'],
            default='mp4',
            help='Output format (default: mp4)'
        )

        parser.add_argument(
            '--quality',
            choices=['low', 'medium', 'high'],
            default='medium',
            help='Output quality (default: medium)'
        )

        # Utility commands
        parser.add_argument(
            '--example',
            choices=['incline', 'pulley'],
            help='Generate example scene'
        )

        parser.add_argument(
            '--template',
            choices=['incline', 'pulley'],
            help='Print JSON template for scene type'
        )

        parser.add_argument(
            '--validate',
            metavar='FILE',
            help='Validate JSON file without generating diagram'
        )

        # Configuration
        parser.add_argument(
            '--config',
            help='Configuration file for custom settings'
        )

        parser.add_argument(
            '--verbose', '-v',
            action='store_true',
            help='Verbose output'
        )

        return parser

    def get_example_scene(self, scene_type: str) -> Dict[str, Any]:
        """Get example scene JSON for given type."""
        examples = {
            'incline': {
                "scene_type": "incline_plane",
                "objects": [
                    {"type": "incline", "angle": 30, "length": 5.0, "base": [0, 0]},
                    {"type": "block", "position": [2, 1], "on": "incline"}
                ],
                "forces": [
                    {"type": "gravity", "on": "block", "direction": "down"},
                    {"type": "normal", "on": "block", "direction": "perpendicular_to_incline"}
                ]
            },
            'pulley': {
                "scene_type": "pulley_incline",
                "objects": [
                    {"type": "incline", "angle": 30, "length": 5.0, "base": [0, 0]},
                    {"type": "block", "position": [4, 2], "on": "incline"},
                    {"type": "block", "position": [4, -1], "on": "pulley"}
                ],
                "pulley_radius": 0.3,
                "rope_length": 3.0
            }
        }
        return examples.get(scene_type, {})

    def get_template(self, scene_type: str) -> str:
        """Get JSON template string for scene type."""
        templates = {
            'incline': '''
{
  "scene_type": "incline_plane",
  "objects": [
    { "type": "incline", "angle": 30, "length": 5.0, "base": [0, 0] },
    { "type": "block", "position": [2, 1], "on": "incline" }
  ],
  "forces": [
    { "type": "gravity", "on": "block", "direction": "down" },
    { "type": "normal", "on": "block", "direction": "perpendicular_to_incline" }
  ]
}''',
            'pulley': '''
{
  "scene_type": "pulley_incline",
  "objects": [
    { "type": "incline", "angle": 30, "length": 5.0, "base": [0, 0] },
    { "type": "block", "position": [4, 2], "on": "incline" },
    { "type": "block", "position": [4, -1], "on": "pulley" }
  ],
  "pulley_radius": 0.3,
  "rope_length": 3.0
}'''
        }
        return templates.get(scene_type, "")

    def validate_file(self, file_path: str) -> bool:
        """Validate JSON file."""
        try:
            with open(file_path, 'r') as f:
                json_data = json.load(f)

            self.generator.validate_json(json_data)
            print(f"✅ {file_path} is valid")
            return True

        except Exception as e:
            print(f"❌ Validation failed: {str(e)}")
            return False

    def configure_quality(self, quality: str):
        """Configure output quality settings."""
        quality_settings = {
            'low': {"pixel_height": 480, "pixel_width": 854, "frame_rate": 15},
            'medium': {"pixel_height": 720, "pixel_width": 1280, "frame_rate": 30},
            'high': {"pixel_height": 1080, "pixel_width": 1920, "frame_rate": 60}
        }

        if quality in quality_settings:
            self.generator.config.update(quality_settings[quality])

    def run(self, args: argparse.Namespace) -> int:
        """Run the CLI application."""

        # Handle template command
        if args.template:
            template = self.get_template(args.template)
            if template:
                print(f"JSON Template for {args.template} scene:")
                print(template)
            else:
                print(f"❌ Unknown template type: {args.template}")
                return 1
            return 0

        # Handle validation command
        if args.validate:
            return 0 if self.validate_file(args.validate) else 1

        # Handle example command
        if args.example:
            scene_data = self.get_example_scene(args.example)
            if not scene_data:
                print(f"❌ Unknown example type: {args.example}")
                return 1

            output_name = f"{args.example}_example"
            self.configure_quality(args.quality)

            if args.verbose:
                print(f"📊 Generating {args.example} example...")
                print(f"🎯 Output: {output_name}")
                print(f"⚙️  Quality: {args.quality}")

            success = self.generator.generate_from_json(scene_data, output_name)
            return 0 if success else 1

        # Handle file input
        if not args.input_file:
            print("❌ Error: No input file specified")
            print("Use --help for usage information")
            return 1

        if not os.path.exists(args.input_file):
            print(f"❌ Error: File not found: {args.input_file}")
            return 1

        # Configure quality
        self.configure_quality(args.quality)

        if args.verbose:
            print(f"📂 Input: {args.input_file}")
            print(f"🎯 Output: {args.output}")
            print(f"🎬 Format: {args.format}")
            print(f"⚙️  Quality: {args.quality}")

        # Generate diagram
        success = self.generator.generate_from_json_file(args.input_file, args.output)
        return 0 if success else 1


def main():
    """Main entry point."""
    cli = PhysicsCLI()
    parser = cli.setup_parser()
    args = parser.parse_args()

    try:
        return cli.run(args)
    except KeyboardInterrupt:
        print("\n⏹️  Operation cancelled by user")
        return 130
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())