import json
import numpy as np
from manim import *
from typing import Dict, List, Any, Tuple
import math

class PhysicsDiagramScene(Scene):
    """Base scene for rendering physics diagrams from JSON descriptions."""

    def __init__(self, json_data: Dict[str, Any], **kwargs):
        super().__init__(**kwargs)
        self.json_data = json_data
        self.scene_objects = {}  # Store created manim objects
        self.scale_factor = 1.0

    def construct(self):
        """Main construction method that routes to appropriate scene type."""
        scene_type = self.json_data.get("scene_type", "")

        if scene_type == "incline_plane":
            self.create_incline_plane_scene()
        elif scene_type == "pulley_incline":
            self.create_pulley_incline_scene()
        else:
            raise ValueError(f"Unknown scene type: {scene_type}")

        # Add title
        title = Text("Physics Diagram", font_size=24)
        title.to_edge(UP)
        self.add(title)

    def create_incline_plane_scene(self):
        """Create an incline plane scene with blocks and forces."""
        objects = self.json_data.get("objects", [])
        forces = self.json_data.get("forces", [])

        # Create objects
        for obj in objects:
            if obj["type"] == "incline":
                self.create_incline(obj)
            elif obj["type"] == "block":
                self.create_block(obj)

        # Create forces
        for force in forces:
            self.create_force(force)

        # Add labels and measurements
        self.add_measurements()

    def create_pulley_incline_scene(self):
        """Create a pulley-incline scene with hanging masses."""
        objects = self.json_data.get("objects", [])
        pulley_radius = self.json_data.get("pulley_radius", 0.3)
        rope_length = self.json_data.get("rope_length", 3.0)

        # Find incline to determine pulley position
        incline_obj = next((obj for obj in objects if obj["type"] == "incline"), None)
        if not incline_obj:
            raise ValueError("Pulley scene requires an incline")

        # Create objects
        for obj in objects:
            if obj["type"] == "incline":
                self.create_incline(obj)
            elif obj["type"] == "block":
                self.create_block(obj)

        # Create pulley
        self.create_pulley(incline_obj, pulley_radius)

        # Create rope
        self.create_rope(objects, rope_length)

        # Add labels
        self.add_measurements()

    def create_incline(self, incline_data: Dict[str, Any]):
        """Create an inclined plane."""
        angle = incline_data["angle"]
        length = incline_data["length"]
        base = incline_data["base"]

        # Convert to radians
        angle_rad = math.radians(angle)

        # Calculate incline vertices
        start_point = np.array([base[0], base[1], 0])
        end_point = np.array([
            base[0] + length * math.cos(angle_rad),
            base[1] + length * math.sin(angle_rad),
            0
        ])

        # Create incline as a line with thickness
        incline_line = Line(start_point, end_point, stroke_width=8, color=BLUE)

        # Create base line
        base_line = Line(
            start_point,
            np.array([start_point[0] + length * math.cos(angle_rad), start_point[1], 0]),
            stroke_width=4,
            color=GRAY
        )

        # Create angle arc
        angle_arc = Arc(
            radius=0.5,
            start_angle=0,
            angle=angle_rad,
            color=GREEN
        ).move_arc_center_to(start_point)

        # Angle label
        angle_label = Text(f"{angle}°", font_size=20, color=GREEN)
        angle_label.next_to(angle_arc, RIGHT, buff=0.1)

        # Store objects
        self.scene_objects['incline'] = {
            'line': incline_line,
            'base': base_line,
            'angle_arc': angle_arc,
            'angle_label': angle_label,
            'data': incline_data
        }

        # Add to scene
        self.add(incline_line, base_line, angle_arc, angle_label)

    def create_block(self, block_data: Dict[str, Any]):
        """Create a block (mass) object."""
        position = block_data["position"]
        on_surface = block_data.get("on", "ground")

        # Create block as a square
        block = Square(side_length=0.4, fill_color=RED, fill_opacity=0.8, stroke_color=RED_D)

        # If block is on incline, calculate proper position and rotation
        if on_surface == "incline" and 'incline' in self.scene_objects:
            incline_data = self.scene_objects['incline']['data']
            angle = incline_data['angle']
            length = incline_data['length']
            base = incline_data['base']

            # Calculate position along incline
            angle_rad = math.radians(angle)

            # Use position[0] as distance along incline from base
            distance_along_incline = position[0]

            # Calculate actual x,y position on incline surface
            actual_x = base[0] + distance_along_incline * math.cos(angle_rad)
            actual_y = base[1] + distance_along_incline * math.sin(angle_rad)

            # Offset slightly above the incline line so block sits on top
            offset_distance = 0.2  # Half the block height
            offset_x = -offset_distance * math.sin(angle_rad)
            offset_y = offset_distance * math.cos(angle_rad)

            final_position = np.array([actual_x + offset_x, actual_y + offset_y, 0])
            block.move_to(final_position)

            # Rotate block to match incline angle
            block.rotate(angle_rad)

        else:
            # Default positioning for non-incline blocks
            block.move_to(np.array([position[0], position[1], 0]))

        # Add mass label
        block_label = Text("m", font_size=16, color=WHITE)
        block_label.move_to(block.get_center())

        # Store block info
        block_id = f"block_{len([k for k in self.scene_objects.keys() if k.startswith('block')])}"
        self.scene_objects[block_id] = {
            'square': block,
            'label': block_label,
            'data': block_data
        }

        # Add to scene
        self.add(block, block_label)

    def create_force(self, force_data: Dict[str, Any]):
        """Create a force vector."""
        force_type = force_data["type"]
        on_object = force_data["on"]
        direction = force_data["direction"]

        # Find the object this force acts on
        target_block = None
        for obj_id, obj_info in self.scene_objects.items():
            if obj_id.startswith('block') and obj_info['data'].get('on') == on_object.replace('block', ''):
                target_block = obj_info
                break

        if not target_block:
            # Find block by matching pattern
            for obj_id, obj_info in self.scene_objects.items():
                if obj_id.startswith('block'):
                    target_block = obj_info
                    break

        if not target_block:
            return

        # Get block center
        block_center = target_block['square'].get_center()

        # Determine force direction vector
        if direction == "down":
            force_vector = DOWN
            color = YELLOW
            label = "mg"
        elif direction == "perpendicular_to_incline":
            # Calculate normal direction
            if 'incline' in self.scene_objects:
                angle = self.scene_objects['incline']['data']['angle']
                angle_rad = math.radians(angle)
                # Normal is perpendicular to incline surface (pointing away from incline)
                normal_angle = angle_rad + math.pi/2
                force_vector = np.array([
                    math.cos(normal_angle),
                    math.sin(normal_angle),
                    0
                ])
            else:
                force_vector = UP
            color = PURPLE
            label = "N"
        else:
            force_vector = UP
            color = GREEN
            label = "F"

        # Create force arrow with longer length for visibility
        arrow_length = 1.2
        force_arrow = Arrow(
            start=block_center,
            end=block_center + force_vector * arrow_length,
            color=color,
            stroke_width=4,
            tip_length=0.2
        )

        # Create force label
        force_label = Text(label, font_size=16, color=color)
        force_label.next_to(force_arrow.get_end(), force_vector * 0.3)

        # Store force
        force_id = f"force_{force_type}"
        self.scene_objects[force_id] = {
            'arrow': force_arrow,
            'label': force_label,
            'data': force_data
        }

        # Add to scene
        self.add(force_arrow, force_label)

    def create_pulley(self, incline_data: Dict[str, Any], radius: float):
        """Create a pulley at the top of the incline."""
        angle = incline_data["angle"]
        length = incline_data["length"]
        base = incline_data["base"]

        # Calculate pulley position (top of incline)
        angle_rad = math.radians(angle)
        pulley_center = np.array([
            base[0] + length * math.cos(angle_rad),
            base[1] + length * math.sin(angle_rad),
            0
        ])

        # Create pulley circle
        pulley = Circle(radius=radius, color=ORANGE, stroke_width=4)
        pulley.move_to(pulley_center)

        # Add center dot
        center_dot = Dot(pulley_center, color=ORANGE)

        # Store pulley
        self.scene_objects['pulley'] = {
            'circle': pulley,
            'center': center_dot,
            'position': pulley_center
        }

        # Add to scene
        self.add(pulley, center_dot)

    def create_rope(self, objects: List[Dict], rope_length: float):
        """Create rope connecting blocks through pulley."""
        # Find blocks
        incline_block = None
        hanging_block = None

        for obj in objects:
            if obj["type"] == "block":
                if obj.get("on") == "incline":
                    incline_block = obj
                elif obj.get("on") == "pulley":
                    hanging_block = obj

        if not incline_block or not hanging_block or 'pulley' not in self.scene_objects:
            return

        # Get positions
        incline_pos = np.array([incline_block["position"][0], incline_block["position"][1], 0])
        hanging_pos = np.array([hanging_block["position"][0], hanging_block["position"][1], 0])
        pulley_pos = self.scene_objects['pulley']['position']

        # Create rope segments
        rope1 = Line(incline_pos, pulley_pos, color=BROWN, stroke_width=3)
        rope2 = Line(pulley_pos, hanging_pos, color=BROWN, stroke_width=3)

        # Store rope
        self.scene_objects['rope'] = {
            'segment1': rope1,
            'segment2': rope2
        }

        # Add to scene
        self.add(rope1, rope2)

    def add_measurements(self):
        """Add measurement labels and dimensions."""
        if 'incline' in self.scene_objects:
            incline_data = self.scene_objects['incline']['data']
            length = incline_data['length']

            # Add length measurement
            length_label = Text(f"L = {length}", font_size=14)
            length_label.to_edge(DOWN + LEFT)
            self.add(length_label)


class PhysicsDiagramGenerator:
    """Main class for generating physics diagrams from JSON."""

    def __init__(self):
        self.config = {
            "pixel_height": 720,
            "pixel_width": 1280,
            "frame_rate": 15,
            "background_color": WHITE
        }

    def generate_from_json(self, json_data: Dict[str, Any], output_path: str = "physics_diagram"):
        """Generate a diagram from JSON scene description."""
        try:
            # Validate JSON structure
            self.validate_json(json_data)

            # Create scene
            scene = PhysicsDiagramScene(json_data)

            # Configure manim to avoid LaTeX
            config.pixel_height = self.config["pixel_height"]
            config.pixel_width = self.config["pixel_width"]
            config.frame_rate = self.config["frame_rate"]
            config.background_color = self.config["background_color"]

            # Disable LaTeX
            config.disable_caching = True

            # Render scene
            scene.render(output_path)

            print(f"✅ Diagram generated successfully: {output_path}")
            return True

        except Exception as e:
            print(f"❌ Error generating diagram: {str(e)}")
            return False

    def generate_from_json_file(self, json_file_path: str, output_path: str = "physics_diagram"):
        """Generate diagram from JSON file."""
        try:
            with open(json_file_path, 'r') as f:
                json_data = json.load(f)
            return self.generate_from_json(json_data, output_path)
        except Exception as e:
            print(f"❌ Error reading JSON file: {str(e)}")
            return False

    def validate_json(self, json_data: Dict[str, Any]):
        """Validate JSON structure matches expected schema."""
        required_fields = ["scene_type", "objects"]

        for field in required_fields:
            if field not in json_data:
                raise ValueError(f"Missing required field: {field}")

        scene_type = json_data["scene_type"]
        if scene_type not in ["incline_plane", "pulley_incline"]:
            raise ValueError(f"Unknown scene type: {scene_type}")

        # Validate objects
        objects = json_data["objects"]
        if not isinstance(objects, list) or len(objects) == 0:
            raise ValueError("Objects must be a non-empty list")

        # Additional validation for pulley scenes
        if scene_type == "pulley_incline":
            if "pulley_radius" not in json_data:
                json_data["pulley_radius"] = 0.3  # Default value
            if "rope_length" not in json_data:
                json_data["rope_length"] = 3.0  # Default value


# Example usage and test cases
def test_generator():
    """Test the diagram generator with example JSON data."""

    # Test case 1: Simple incline plane
    incline_scene = {
        "scene_type": "incline_plane",
        "objects": [
            {"type": "incline", "angle": 30, "length": 5.0, "base": [0, 0]},
            {"type": "block", "position": [2, 1], "on": "incline"}
        ],
        "forces": [
            {"type": "gravity", "on": "block", "direction": "down"},
            {"type": "normal", "on": "block", "direction": "perpendicular_to_incline"}
        ]
    }

    # Test case 2: Pulley incline system
    pulley_scene = {
        "scene_type": "pulley_incline",
        "objects": [
            {"type": "incline", "angle": 30, "length": 5.0, "base": [0, 0]},
            {"type": "block", "position": [4, 2], "on": "incline"},
            {"type": "block", "position": [4, -1], "on": "pulley"}
        ],
        "pulley_radius": 0.3,
        "rope_length": 3.0
    }

    # Generate diagrams
    generator = PhysicsDiagramGenerator()

    print("🎬 Generating incline plane diagram...")
    generator.generate_from_json(incline_scene, "incline_diagram")

    print("🎬 Generating pulley incline diagram...")
    generator.generate_from_json(pulley_scene, "pulley_diagram")


if __name__ == "__main__":
    # Example usage
    generator = PhysicsDiagramGenerator()

    # Example JSON (matching your template format)
    example_json = {
        "scene_type": "incline_plane",
        "objects": [
            {"type": "incline", "angle": 25, "length": 5.0, "base": [0, 0]},
            {"type": "block", "position": [2, 1], "on": "incline"}
        ],
        "forces": [
            {"type": "gravity", "on": "block", "direction": "down"},
            {"type": "normal", "on": "block", "direction": "perpendicular_to_incline"}
        ]
    }

    # Generate diagram
    generator.generate_from_json(example_json, "my_physics_diagram")

    # Or from file
    # generator.generate_from_json_file("scene.json", "output_diagram")