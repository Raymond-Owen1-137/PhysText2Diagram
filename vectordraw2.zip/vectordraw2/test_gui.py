import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import webbrowser
import json
import math
import numpy as np

# Try to import clipboard functionality
try:
    import pyperclip
    CLIPBOARD_AVAILABLE = True
except ImportError:
    CLIPBOARD_AVAILABLE = False

# Check if manim is available
try:
    from manim import Scene, WHITE, Line, Arc, Square, Arrow, Text
    from manim import BLUE, GRAY, GREEN, RED, RED_D, YELLOW, PURPLE, BLACK, DOWN, RIGHT, UP
    from manim import config
    MANIM_AVAILABLE = True
except ImportError:
    MANIM_AVAILABLE = False

class PhysicsGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Physics Diagram Generator - Complete Version")
        self.root.geometry("1000x700")

        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Create all tabs
        self.create_text_to_json_tab()
        self.create_json_result_tab()
        self.create_3d_prompt_tab()
        self.create_batch_tab()

        # Status/log area
        self.create_log_area()

        # Initial status
        self.log_initial_status()

    def create_text_to_json_tab(self):
        """Create Tab 1: Text to JSON conversion."""
        self.tab1 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab1, text="📝 Text → JSON")

        # Problem input
        ttk.Label(self.tab1, text="Physics Problem:", font=("Arial", 12, "bold")).pack(anchor="w", padx=5, pady=5)
        self.problem_text = scrolledtext.ScrolledText(self.tab1, height=8, font=("Consolas", 10))
        self.problem_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.problem_text.insert(tk.END, "A 2.0 kg block rests on a 30° frictionless incline.")

        # Buttons
        button_frame1 = ttk.Frame(self.tab1)
        button_frame1.pack(fill=tk.X, padx=5, pady=5)

        ttk.Button(button_frame1, text="🤖 Generate ChatGPT Prompt", command=self.generate_prompt).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame1, text="📋 Copy Prompt", command=self.copy_prompt).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame1, text="🌐 Open ChatGPT", command=self.open_chatgpt).pack(side=tk.LEFT, padx=5)

        # Prompt output
        ttk.Label(self.tab1, text="ChatGPT Prompt (Copy This):", font=("Arial", 12, "bold")).pack(anchor="w", padx=5, pady=(10,5))
        self.output_text = scrolledtext.ScrolledText(self.tab1, height=12, font=("Consolas", 9), bg="#f8f9fa")
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def create_json_result_tab(self):
        """Create Tab 2: JSON to diagram conversion."""
        self.tab2 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab2, text="📋 JSON Result")

        # JSON input
        ttk.Label(self.tab2, text="Paste JSON from ChatGPT:", font=("Arial", 12, "bold")).pack(anchor="w", padx=5, pady=5)
        self.json_text = scrolledtext.ScrolledText(self.tab2, height=15, font=("Consolas", 10))
        self.json_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # JSON buttons
        button_frame2 = ttk.Frame(self.tab2)
        button_frame2.pack(fill=tk.X, padx=5, pady=5)

        ttk.Button(button_frame2, text="✅ Validate JSON", command=self.validate_json).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame2, text="💾 Save JSON", command=self.save_json).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame2, text="🎬 Generate Diagram", command=self.generate_manim_diagram).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame2, text="🎨 Generate 3D Prompt", command=self.generate_3d_prompt).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame2, text="📁 Open Folder", command=self.open_output_folder).pack(side=tk.LEFT, padx=5)

    def create_3d_prompt_tab(self):
        """Create Tab 3: 3D image prompt generation."""
        self.tab3 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab3, text="🎨 3D Image Prompt")

        ttk.Label(self.tab3, text="3D Image Prompt for ChatGPT/DALL-E:", font=("Arial", 12, "bold")).pack(anchor="w", padx=5, pady=5)
        self.prompt_3d_text = scrolledtext.ScrolledText(self.tab3, height=20, font=("Consolas", 9), bg="#f8f9fa")
        self.prompt_3d_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        button_frame3 = ttk.Frame(self.tab3)
        button_frame3.pack(fill=tk.X, padx=5, pady=5)

        ttk.Button(button_frame3, text="📋 Copy 3D Prompt", command=self.copy_3d_prompt).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame3, text="🌐 Open ChatGPT", command=self.open_chatgpt).pack(side=tk.LEFT, padx=5)

    def create_batch_tab(self):
        """Create Tab 4: Batch processing."""
        self.tab4 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab4, text="⚡ Batch Generator")

        # Batch Settings
        batch_settings_frame = ttk.LabelFrame(self.tab4, text="Batch Generation Settings", padding=10)
        batch_settings_frame.pack(fill=tk.X, padx=5, pady=5)

        # Template selection
        template_row = ttk.Frame(batch_settings_frame)
        template_row.pack(fill=tk.X, pady=2)

        ttk.Label(template_row, text="Template:").pack(side=tk.LEFT, padx=5)
        self.batch_template_var = tk.StringVar(value="incline_plane")
        template_combo = ttk.Combobox(template_row, textvariable=self.batch_template_var,
                                    values=["incline_plane", "pulley_incline"], state="readonly", width=15)
        template_combo.pack(side=tk.LEFT, padx=5)

        # Parameter ranges
        params_frame = ttk.LabelFrame(batch_settings_frame, text="Parameter Ranges", padding=5)
        params_frame.pack(fill=tk.X, pady=5)

        # Angle range
        angle_row = ttk.Frame(params_frame)
        angle_row.pack(fill=tk.X, pady=2)

        ttk.Label(angle_row, text="Angles:").pack(side=tk.LEFT, padx=5)
        self.angle_start_var = tk.StringVar(value="15")
        ttk.Entry(angle_row, textvariable=self.angle_start_var, width=5).pack(side=tk.LEFT, padx=2)
        ttk.Label(angle_row, text="to").pack(side=tk.LEFT, padx=2)
        self.angle_end_var = tk.StringVar(value="75")
        ttk.Entry(angle_row, textvariable=self.angle_end_var, width=5).pack(side=tk.LEFT, padx=2)
        ttk.Label(angle_row, text="step").pack(side=tk.LEFT, padx=2)
        self.angle_step_var = tk.StringVar(value="15")
        ttk.Entry(angle_row, textvariable=self.angle_step_var, width=5).pack(side=tk.LEFT, padx=2)
        ttk.Label(angle_row, text="degrees").pack(side=tk.LEFT, padx=2)

        # Mass range
        mass_row = ttk.Frame(params_frame)
        mass_row.pack(fill=tk.X, pady=2)

        ttk.Label(mass_row, text="Masses:").pack(side=tk.LEFT, padx=5)
        self.mass_values_var = tk.StringVar(value="1.0, 2.0, 5.0")
        ttk.Entry(mass_row, textvariable=self.mass_values_var, width=20).pack(side=tk.LEFT, padx=2)
        ttk.Label(mass_row, text="kg (comma-separated)").pack(side=tk.LEFT, padx=2)

        # Length range
        length_row = ttk.Frame(params_frame)
        length_row.pack(fill=tk.X, pady=2)

        ttk.Label(length_row, text="Lengths:").pack(side=tk.LEFT, padx=5)
        self.length_values_var = tk.StringVar(value="3.0, 4.0, 5.0")
        ttk.Entry(length_row, textvariable=self.length_values_var, width=20).pack(side=tk.LEFT, padx=2)
        ttk.Label(length_row, text="units (comma-separated)").pack(side=tk.LEFT, padx=2)

        # Output settings
        output_row = ttk.Frame(batch_settings_frame)
        output_row.pack(fill=tk.X, pady=5)

        ttk.Label(output_row, text="Output Prefix:").pack(side=tk.LEFT, padx=5)
        self.prefix_var = tk.StringVar(value="physics_problem")
        ttk.Entry(output_row, textvariable=self.prefix_var, width=15).pack(side=tk.LEFT, padx=5)

        self.generate_diagrams_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(output_row, text="Generate Diagrams", variable=self.generate_diagrams_var).pack(side=tk.LEFT, padx=10)

        self.save_json_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(output_row, text="Save JSON Files", variable=self.save_json_var).pack(side=tk.LEFT, padx=10)

        # Preview and Generate
        preview_frame = ttk.LabelFrame(self.tab4, text="Preview & Generate", padding=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Buttons
        button_row = ttk.Frame(preview_frame)
        button_row.pack(fill=tk.X, pady=5)

        ttk.Button(button_row, text="👁️ Preview Batch", command=self.preview_batch).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_row, text="⚡ Generate All", command=self.generate_batch).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_row, text="📁 Open Output Folder", command=self.open_output_folder).pack(side=tk.LEFT, padx=5)

        # Preview area
        ttk.Label(preview_frame, text="Batch Preview:", font=("Arial", 10, "bold")).pack(anchor="w", pady=(10,2))
        self.preview_text = scrolledtext.ScrolledText(preview_frame, height=12, font=("Consolas", 9), bg="#f8f9fa")
        self.preview_text.pack(fill=tk.BOTH, expand=True, pady=2)

        # Batch log
        ttk.Label(preview_frame, text="Batch Progress:", font=("Arial", 10, "bold")).pack(anchor="w", pady=(10,2))
        self.batch_log_text = scrolledtext.ScrolledText(preview_frame, height=8, font=("Consolas", 9), bg="#f0f0f0")
        self.batch_log_text.pack(fill=tk.BOTH, expand=True, pady=2)

    def create_log_area(self):
        """Create the activity log area."""
        ttk.Label(self.root, text="Activity Log:", font=("Arial", 10, "bold")).pack(anchor="w", padx=15)
        self.log_text = scrolledtext.ScrolledText(self.root, height=6, font=("Consolas", 9), bg="#f0f0f0")
        self.log_text.pack(fill=tk.X, padx=10, pady=(0,10))

    def log_initial_status(self):
        """Log initial status messages."""
        if CLIPBOARD_AVAILABLE:
            self.log_text.insert(tk.END, "✅ Clipboard support available\n")
        else:
            self.log_text.insert(tk.END, "⚠️ Clipboard not available - you'll need to copy manually\n")

        if MANIM_AVAILABLE:
            self.log_text.insert(tk.END, "✅ Manim available - can generate diagrams!\n")
        else:
            self.log_text.insert(tk.END, "⚠️ Manim not available - 3D prompts only\n")

        self.log_text.insert(tk.END, "🚀 Ready! Follow the tabs: Text → JSON → Diagram/3D Prompt\n")

    def generate_prompt(self):
        """Generate ChatGPT prompt for text to JSON conversion."""
        problem_text = self.problem_text.get(1.0, tk.END).strip()

        if not problem_text:
            messagebox.showwarning("Warning", "Please enter a physics problem first.")
            return

        prompt = f"""I have a physics word problem that I need converted to JSON format for a diagram generator.

PROBLEM:
{problem_text}

INSTRUCTIONS:
Convert this problem into JSON format following this schema:

For incline plane problems:
{{
  "scene_type": "incline_plane",
  "objects": [
    {{"type": "incline", "angle": NUMBER, "length": NUMBER, "base": [NUMBER, NUMBER]}},
    {{"type": "block", "position": [NUMBER, NUMBER], "on": "incline"}}
  ],
  "forces": [
    {{"type": "gravity", "on": "block", "direction": "down"}},
    {{"type": "normal", "on": "block", "direction": "perpendicular_to_incline"}}
  ]
}}

For pulley-incline problems:
{{
  "scene_type": "pulley_incline",
  "objects": [
    {{"type": "incline", "angle": NUMBER, "length": NUMBER, "base": [NUMBER, NUMBER]}},
    {{"type": "block", "position": [NUMBER, NUMBER], "on": "incline"}},
    {{"type": "block", "position": [NUMBER, NUMBER], "on": "pulley"}}
  ],
  "pulley_radius": NUMBER,
  "rope_length": NUMBER
}}

Rules:
- Output ONLY the JSON, no explanation
- Use degrees for angles, default length 5.0
- Position as [x, y] coordinates

Please convert this problem into the appropriate JSON format."""

        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, prompt)
        self.log_text.insert(tk.END, "✅ ChatGPT prompt generated!\n")

    def copy_prompt(self):
        """Copy ChatGPT prompt to clipboard."""
        prompt = self.output_text.get(1.0, tk.END).strip()
        if CLIPBOARD_AVAILABLE and prompt:
            pyperclip.copy(prompt)
            self.log_text.insert(tk.END, "📋 Prompt copied to clipboard!\n")
        elif prompt:
            messagebox.showinfo("Copy Manually", "Select all text and copy manually (Ctrl+A, Ctrl+C)")
        else:
            messagebox.showwarning("Warning", "No prompt to copy. Generate one first!")

    def open_chatgpt(self):
        """Open ChatGPT in browser."""
        webbrowser.open("https://chat.openai.com")

    def validate_json(self):
        """Validate the JSON input."""
        json_content = self.json_text.get(1.0, tk.END).strip()
        if not json_content:
            messagebox.showwarning("Warning", "Please paste JSON first!")
            return False

        try:
            self.current_json = json.loads(json_content)
            required_fields = ["scene_type", "objects"]
            for field in required_fields:
                if field not in self.current_json:
                    raise ValueError(f"Missing required field: {field}")

            messagebox.showinfo("Success", "✅ JSON is valid!")
            self.log_text.insert(tk.END, "✅ JSON validation passed!\n")
            return True

        except json.JSONDecodeError as e:
            messagebox.showerror("JSON Error", f"Invalid JSON format:\n{str(e)}")
            self.log_text.insert(tk.END, f"❌ JSON Error: {str(e)}\n")
            return False
        except Exception as e:
            messagebox.showerror("Validation Error", f"JSON validation failed:\n{str(e)}")
            self.log_text.insert(tk.END, f"❌ Validation Error: {str(e)}\n")
            return False

    def save_json(self):
        """Save current JSON to file."""
        json_content = self.json_text.get(1.0, tk.END).strip()
        if not json_content:
            messagebox.showwarning("Warning", "No JSON to save!")
            return

        try:
            data = json.loads(json_content)
            filename = "physics_problem.json"
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
            messagebox.showinfo("Success", f"JSON saved as {filename}")
            self.log_text.insert(tk.END, f"💾 JSON saved as {filename}\n")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save JSON:\n{str(e)}")

    def generate_manim_diagram(self):
        """Generate Manim diagram from JSON."""
        if not hasattr(self, 'current_json') or not self.current_json:
            if not self.validate_json():
                return

        if not MANIM_AVAILABLE:
            messagebox.showerror("Manim Not Available",
                               "Manim is not installed.\n\nInstall with: pip install manim")
            return

        self.log_text.insert(tk.END, "🎬 Starting Manim diagram generation...\n")

        def generate_thread():
            try:
                class SimplePhysicsScene(Scene):
                    def __init__(self, json_data, **kwargs):
                        super().__init__(**kwargs)
                        self.json_data = json_data

                    def construct(self):
                        self.camera.background_color = WHITE

                        objects = self.json_data.get("objects", [])
                        incline_obj = next((obj for obj in objects if obj["type"] == "incline"), None)
                        if not incline_obj:
                            return

                        angle = incline_obj["angle"]
                        length = incline_obj.get("length", 5.0)
                        base = incline_obj.get("base", [0, 0])

                        # Create incline
                        angle_rad = math.radians(angle)
                        start_point = np.array([base[0] - 2, base[1], 0])
                        end_point = np.array([
                            start_point[0] + length * math.cos(angle_rad),
                            start_point[1] + length * math.sin(angle_rad), 0
                        ])

                        incline_line = Line(start_point, end_point, stroke_width=8, color=BLUE)
                        base_line = Line(start_point, np.array([end_point[0], start_point[1], 0]),
                                       stroke_width=4, color=GRAY)

                        angle_arc = Arc(radius=0.8, start_angle=0, angle=angle_rad, color=GREEN)
                        angle_arc.move_arc_center_to(start_point)

                        angle_label = Text(f"{angle}°", font_size=24, color=GREEN)
                        angle_label.next_to(angle_arc, RIGHT, buff=0.2)

                        # Create block
                        distance_along = length * 0.6
                        actual_x = start_point[0] + distance_along * math.cos(angle_rad)
                        actual_y = start_point[1] + distance_along * math.sin(angle_rad)

                        offset_distance = 0.3
                        offset_x = -offset_distance * math.sin(angle_rad)
                        offset_y = offset_distance * math.cos(angle_rad)

                        block_pos = np.array([actual_x + offset_x, actual_y + offset_y, 0])
                        block = Square(side_length=0.5, fill_color=RED, fill_opacity=0.8, stroke_color=RED_D)
                        block.move_to(block_pos)
                        block.rotate(angle_rad)

                        mass_label = Text("m", font_size=18, color=WHITE)
                        mass_label.move_to(block_pos)

                        # Forces
                        forces = self.json_data.get("forces", [])
                        force_objects = []

                        for force in forces:
                            if force.get("on") == "block":
                                if force.get("direction") == "down":
                                    gravity_arrow = Arrow(start=block_pos, end=block_pos + DOWN * 1.5,
                                                        color=YELLOW, stroke_width=6, tip_length=0.3)
                                    gravity_label = Text("mg", font_size=16, color=YELLOW)
                                    gravity_label.next_to(gravity_arrow.get_end(), DOWN, buff=0.1)
                                    force_objects.extend([gravity_arrow, gravity_label])

                                elif force.get("direction") == "perpendicular_to_incline":
                                    normal_angle = angle_rad + math.pi/2
                                    normal_vector = np.array([math.cos(normal_angle), math.sin(normal_angle), 0])

                                    normal_arrow = Arrow(start=block_pos, end=block_pos + normal_vector * 1.5,
                                                       color=PURPLE, stroke_width=6, tip_length=0.3)
                                    normal_label = Text("N", font_size=16, color=PURPLE)
                                    normal_label.next_to(normal_arrow.get_end(), normal_vector * 0.5)
                                    force_objects.extend([normal_arrow, normal_label])

                        # Title and info
                        title = Text("Physics Diagram", font_size=32, color=BLACK)
                        title.to_edge(UP, buff=0.5)

                        info_text = Text(f"Length = {length} units", font_size=16, color=BLACK)
                        info_text.to_edge(DOWN, buff=0.5)

                        # Add all elements
                        self.add(incline_line, base_line, angle_arc, angle_label)
                        self.add(block, mass_label)
                        self.add(*force_objects)
                        self.add(title, info_text)

                # Configure and render
                config.pixel_height = 720
                config.pixel_width = 1280
                config.frame_rate = 15
                config.background_color = WHITE
                config.output_file = "physics_diagram"

                scene = SimplePhysicsScene(self.current_json)
                scene.render()

                self.root.after(0, lambda: self.log_text.insert(tk.END, "✅ Diagram generated successfully!\n"))
                self.root.after(0, lambda: messagebox.showinfo("Success", "Diagram generated! Check physics_diagram.mp4"))

            except Exception as e:
                error_msg = f"❌ Generation error: {str(e)}"
                self.root.after(0, lambda: self.log_text.insert(tk.END, f"{error_msg}\n"))
                self.root.after(0, lambda: messagebox.showerror("Error", error_msg))

        import threading
        threading.Thread(target=generate_thread, daemon=True).start()

    def generate_3d_prompt(self):
        """Generate 3D image prompt based on current JSON."""
        if not hasattr(self, 'current_json') or not self.current_json:
            messagebox.showwarning("Warning", "Please validate JSON first.")
            return

        try:
            objects = self.current_json.get("objects", [])
            incline = next((obj for obj in objects if obj["type"] == "incline"), None)

            if not incline:
                messagebox.showerror("Error", "No incline found in JSON!")
                return

            angle = incline.get("angle", 30)
            scene_desc = f"an inclined plane experiment with a wooden ramp at {angle}° and a red block resting on it"

            prompt_3d = f"""Create a photorealistic 3D rendered physics diagram showing {scene_desc}.

SCENE SETUP:
- A solid wooden inclined plane ramp at exactly {angle} degrees, with visible wood grain texture
- A metallic red/orange cube (representing mass "m") sitting flush on the incline surface
- The ramp should be about 3-4 feet long, made of oak or pine wood
- A horizontal gray reference surface/table underneath

PHYSICS ELEMENTS:
- Purple arrow labeled "N" pointing perpendicular to the incline surface (normal force)
- Yellow arrow labeled "mg" pointing straight down from the block (gravitational force)
- Both arrows should be clearly visible, professional-looking vectors
- Small "{angle}°" angle marking at the base of the incline
- The block should be positioned about 1/3 up the ramp

VISUAL STYLE:
- Photorealistic 3D rendering with soft studio lighting
- Clean, educational/textbook quality
- Neutral background (light gray or white)
- Professional physics lab aesthetic
- Sharp focus with subtle shadows
- Slightly elevated camera angle showing the 3D perspective clearly

MATERIALS:
- Wood: Natural oak with visible grain, slight satin finish
- Block: Brushed aluminum or painted metal with slight reflectivity
- Arrows: Clean, bold colors (purple and yellow) with slight glow
- Text labels: Clean sans-serif font, slightly raised/embossed

Render this as if it's a high-quality physics textbook illustration brought to life in 3D."""

            self.prompt_3d_text.delete(1.0, tk.END)
            self.prompt_3d_text.insert(tk.END, prompt_3d)
            self.log_text.insert(tk.END, "🎨 3D prompt generated!\n")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to generate 3D prompt:\n{str(e)}")

    def copy_3d_prompt(self):
        """Copy 3D prompt to clipboard."""
        prompt = self.prompt_3d_text.get(1.0, tk.END).strip()
        if CLIPBOARD_AVAILABLE and prompt:
            pyperclip.copy(prompt)
            self.log_text.insert(tk.END, "📋 3D prompt copied to clipboard!\n")
        elif prompt:
            messagebox.showinfo("Copy Manually", "Select all text and copy manually (Ctrl+A, Ctrl+C)")
        else:
            messagebox.showwarning("Warning", "No 3D prompt to copy. Generate one first!")

    def open_output_folder(self):
        """Open the output folder."""
        try:
            import os
            os.startfile(".")
        except:
            messagebox.showinfo("Output Location", f"Generated files are in:\n{os.getcwd()}")

    def preview_batch(self):
        """Preview what will be generated in batch."""
        try:
            angle_start = int(self.angle_start_var.get())
            angle_end = int(self.angle_end_var.get())
            angle_step = int(self.angle_step_var.get())

            angles = list(range(angle_start, angle_end + 1, angle_step))
            masses = [float(m.strip()) for m in self.mass_values_var.get().split(',')]
            lengths = [float(l.strip()) for l in self.length_values_var.get().split(',')]

            self.preview_text.delete(1.0, tk.END)
            self.preview_text.insert(tk.END, f"Batch Preview - {self.batch_template_var.get().upper()}\n")
            self.preview_text.insert(tk.END, "=" * 50 + "\n\n")

            count = 0
            for angle in angles:
                for mass in masses:
                    for length in lengths:
                        count += 1
                        filename = f"{self.prefix_var.get()}_{angle}deg_{mass}kg_{length}len"
                        self.preview_text.insert(tk.END, f"{count:2d}. {filename}\n")
                        self.preview_text.insert(tk.END, f"    Angle: {angle}°, Mass: {mass}kg, Length: {length}\n\n")

            self.preview_text.insert(tk.END, f"\nTotal: {count} problems will be generated\n")

            if self.generate_diagrams_var.get() and MANIM_AVAILABLE:
                self.preview_text.insert(tk.END, f"✅ Will generate {count} Manim diagrams\n")
            elif self.generate_diagrams_var.get():
                self.preview_text.insert(tk.END, f"⚠️ Manim not available - diagrams skipped\n")

            if self.save_json_var.get():
                self.preview_text.insert(tk.END, f"✅ Will save {count} JSON files\n")

        except Exception as e:
            self.preview_text.delete(1.0, tk.END)
            self.preview_text.insert(tk.END, f"❌ Preview Error: {str(e)}\n")

    def generate_batch(self):
        """Generate all problems in batch."""
        if not MANIM_AVAILABLE and self.generate_diagrams_var.get():
            if not messagebox.askyesno("Manim Not Available",
                                     "Manim is not installed. Continue with JSON only?"):
                return

        try:
            angle_start = int(self.angle_start_var.get())
            angle_end = int(self.angle_end_var.get())
            angle_step = int(self.angle_step_var.get())

            angles = list(range(angle_start, angle_end + 1, angle_step))
            masses = [float(m.strip()) for m in self.mass_values_var.get().split(',')]
            lengths = [float(l.strip()) for l in self.length_values_var.get().split(',')]

            template = self.batch_template_var.get()
            prefix = self.prefix_var.get()

            import os
            output_dir = f"batch_output_{template}"
            os.makedirs(output_dir, exist_ok=True)

            self.batch_log_text.delete(1.0, tk.END)
            self.batch_log_text.insert(tk.END, f"🚀 Starting batch generation...\n")
            self.batch_log_text.insert(tk.END, f"📁 Output directory: {output_dir}\n\n")

            def batch_worker():
                total_count = len(angles) * len(masses) * len(lengths)
                current_count = 0

                for angle in angles:
                    for mass in masses:
                        for length in lengths:
                            current_count += 1
                            filename = f"{prefix}_{angle}deg_{mass}kg_{length}len"

                            self.root.after(0, lambda: self.batch_log_text.insert(tk.END,
                                f"[{current_count}/{total_count}] Generating {filename}...\n"))

                            try:
                                if template == "incline_plane":
                                    problem_json = {
                                        "scene_type": "incline_plane",
                                        "objects": [
                                            {"type": "incline", "angle": angle, "length": length, "base": [0, 0]},
                                            {"type": "block", "position": [length/2, 0], "on": "incline"}
                                        ],
                                        "forces": [
                                            {"type": "gravity", "on": "block", "direction": "down"},
                                            {"type": "normal", "on": "block", "direction": "perpendicular_to_incline"}
                                        ]
                                    }

                                if self.save_json_var.get():
                                    json_path = os.path.join(output_dir, f"{filename}.json")
                                    with open(json_path, 'w') as f:
                                        json.dump(problem_json, f, indent=2)

                                self.root.after(0, lambda: self.batch_log_text.insert(tk.END, f"✅ {filename} completed\n"))

                            except Exception as e:
                                self.root.after(0, lambda: self.batch_log_text.insert(tk.END, f"❌ {filename} failed: {str(e)}\n"))

                self.root.after(0, lambda: self.batch_log_text.insert(tk.END, f"\n🎉 Batch generation complete!\n"))
                self.root.after(0, lambda: messagebox.showinfo("Batch Complete",
                    f"Generated {total_count} problems!\nCheck {output_dir} folder for results."))

            import threading
            threading.Thread(target=batch_worker, daemon=True).start()

        except Exception as e:
            self.batch_log_text.insert(tk.END, f"❌ Batch Error: {str(e)}\n")
            messagebox.showerror("Batch Error", f"Batch generation failed:\n{str(e)}")

    def run(self):
        """Run the GUI application."""
        self.root.mainloop()

# Create and run the application
if __name__ == "__main__":
    app = PhysicsGUI()
    app.run()