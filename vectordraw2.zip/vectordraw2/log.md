This is vecttordraw2 a start from scratch version of vectordraw but this time i used claud, the images came out a lot cleaner and I used just 1 main file and added a simple gui, there are limited testcases but i plan to improve upon that in vectordraw3 in a few minutes.
the image that is pasted to chat gpt came out almost perfect there was a slight issue with the normal force vector i think it was due to the dalle engine not rotating the image vector when it rotated the perspective.

I added batch processing and it works and has some bugs but i plan to improve on that in next version.

signing off this file vectordraw2
