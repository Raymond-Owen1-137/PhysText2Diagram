#!/usr/bin/env python3
"""
dalle3_pipeline_v2.py  ·  prompt-only edition with budget profiles + live cost
.
"""
import os

# ─────────────────────────────────────────────────────────────────────────────
# 0.   CONFIG  –  tweak these and nothing else
# ─────────────────────────────────────────────────────────────────────────────
QUALITY_PROFILE = "high"          # "low" | "medium" | "high" | add your own
CACHE_PATH      = "dalle_cache_v2.db"

OPENAI_API_KEY  = os.getenv("OPENAI_API_KEY", "")
if not OPENAI_API_KEY:
    raise EnvironmentError("Set OPENAI_API_KEY env var")

# Price table  (USD /-– per-1K-tokens)  – update as OpenAI changes tariffs
PRICE_USD = {
    "gpt-3.5-turbo": {"in": 0.0005, "out": 0.0015},
    "gpt-4o-mini":   {"in": 0.002,  "out": 0.006 },
    "gpt-4o":        {"in": 0.010,  "out": 0.030 }
}

PROFILES = {
    "low": {
        "models": {
            "linguist":  "gpt-3.5-turbo",
            "composer":  "gpt-4o-mini",
            "critic":    "gpt-3.5-turbo",
            "finalizer": "gpt-3.5-turbo"
        },
        "temps": {"linguist": 0.2, "composer": 0.1,
                  "critic":   0.0, "finalizer": 0.0},
        "critic_loops": 1
    },
    "medium": {
        "models": {
            "linguist":  "gpt-4o-mini",
            "composer":  "gpt-4o",
            "critic":    "gpt-4o-mini",
            "finalizer": "gpt-3.5-turbo"
        },
        "temps": {"linguist": 0.2, "composer": 0.1,
                  "critic":   0.0, "finalizer": 0.0},
        "critic_loops": 3
    },
    "high": {
        "models": {
            "linguist":  "gpt-4o",
            "composer":  "gpt-4o",
            "critic":    "gpt-4o",
            "finalizer": "gpt-4o"
        },
        "temps": {"linguist": 0.15, "composer": 0.1,
                  "critic":    0.0, "finalizer": 0.0},
        "critic_loops": 5
    }
}

# --- apply profile
_cfg          = PROFILES[QUALITY_PROFILE]
MODELS        = _cfg["models"]
TEMPS         = _cfg["temps"]
MAX_CRITIC_LOOPS = _cfg["critic_loops"]

# ─────────────────────────────────────────────────────────────────────────────
# 1.   imports
# ─────────────────────────────────────────────────────────────────────────────
import os, json, re, hashlib, logging, time, shelve, textwrap
from typing import Dict, Any, List
import openai
from tenacity import retry, stop_after_attempt, wait_exponential

openai.api_key = OPENAI_API_KEY
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("D3OptV2")

# ─────────────────────────────────────────────────────────────────────────────
# 2.   token meter
# ─────────────────────────────────────────────────────────────────────────────
class TokenMeter:
    def __init__(self):
        self.prompt   = 0
        self.complete = 0
        self.cost     = 0.0
    def add(self, model: str, p: int, c: int):
        self.prompt   += p
        self.complete += c
        rate = PRICE_USD[model]
        self.cost     += (p * rate["in"] + c * rate["out"]) / 1000

meter = TokenMeter()

# ─────────────────────────────────────────────────────────────────────────────
# 3.   utilities
# ─────────────────────────────────────────────────────────────────────────────
def sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

JSON_RE = re.compile(r"\{.*\}", re.S | re.M)
def extract_json(blob: str) -> Dict[str, Any]:
    try:
        return json.loads(JSON_RE.search(blob).group(0))
    except Exception:
        raise ValueError("No valid JSON found")

@retry(stop=stop_after_attempt(3), wait=wait_exponential(1, 2, 10))
def _call_llm(system: str, user: str, model: str, temp: float) -> str:
    rsp = openai.chat.completions.create(
        model=model,
        messages=[{"role":"system","content":system},
                  {"role":"user",  "content":user}],
        temperature=temp
    )
    u = rsp.usage
    meter.add(model, u.prompt_tokens, u.completion_tokens)
    return rsp.choices[0].message.content.strip()

# ─────────────────────────────────────────────────────────────────────────────
# 4.   prompt systems
# ─────────────────────────────────────────────────────────────────────────────
class PS:
    LINGUIST = """You are SceneGraphGPT. Parse physics/problem text into MINIMAL JSON.
Return:
{"objects":[{"type":...,"attrs":{...},"position":"left|right|center|above|below"}...],
 "forces":[{"label":...,"direction":...,"attached_to":...}...],
 "style":{"view":"side view","diagram_style":"flat vector"}}
NO commentary, NO markdown."""
    COMPOSER = """You are PromptComposerGPT. Convert SceneGraph JSON → ONE DALL·E 3 prompt.
Rules:
1. Start "2-D vector diagram, {style.view}, {style.diagram_style}."
2. "Count = X objects:" then bullets for each object.
3. Force arrows lines: "Arrow '{label}' pointing {direction} from {attached_to}."
4. After bullets: "Total objects = X."
5. Specify "Arial font, black text."
6. End with: "White background, flat black lines, no shading, nothing else."
Do NOT add adjectives or omit numbers."""
    CRITIC = """You are PromptCriticGPT. Given SCENE GRAPH and PROMPT, return JSON:
{"ok":true} or {"ok":false,"fix":"Imperative ≤12 words"}.
Check that every object/force/number appears; count matches; labels correct."""
    FINAL  = """You are PromptPolisherGPT. Remove double spaces, fix casing, no semantic edits.
Return cleaned prompt only."""

# ─────────────────────────────────────────────────────────────────────────────
# 5.   pipeline
# ─────────────────────────────────────────────────────────────────────────────
class DallePromptPipeline:
    def __init__(self, cache_path=CACHE_PATH):
        self.cache = shelve.open(cache_path)

    # 5.1  preprocess
    @staticmethod
    def preprocess(text: str) -> str:
        text = text.strip()
        # convert spelled numbers 0-9 to digits
        words = "zero one two three four five six seven eight nine".split()
        text = re.sub(r"\b(" + "|".join(words) + r")\b",
                      lambda m: str(words.index(m.group(0).lower())), text, flags=re.I)
        text = text.replace("kilograms", "kg").replace("kilogram", "kg")
        return text

    # 5.2  scene graph
    def extract_scene_graph(self, problem: str) -> Dict:
        key = f"scene:{sha256(problem)}"
        if key in self.cache:
            return self.cache[key]
        raw   = _call_llm(PS.LINGUIST, problem, MODELS["linguist"], TEMPS["linguist"])
        graph = extract_json(raw)
        self.validate_graph(graph)
        self.cache[key] = graph; self.cache.sync()
        return graph

    @staticmethod
    def validate_graph(g: Dict):
        if "objects" not in g or "forces" not in g:
            raise ValueError("Scene graph missing objects/forces")
        for o in g["objects"]:
            assert "type" in o and "attrs" in o
        for f in g["forces"]:
            assert {"label","direction","attached_to"} <= f.keys()

    # 5.3  compose
    def compose(self, graph: Dict) -> str:
        key = f"comp:{sha256(json.dumps(graph,sort_keys=True))}"
        if key in self.cache: return self.cache[key]
        compact = json.dumps(graph, separators=(",",":"))
        prompt  = _call_llm(PS.COMPOSER, compact, MODELS["composer"], TEMPS["composer"])
        self.cache[key] = prompt; self.cache.sync()
        return prompt

    # 5.4  critic loop
    def critic_loop(self, graph: Dict, prompt: str) -> str:
        compact = json.dumps(graph, separators=(",",":"))
        for i in range(MAX_CRITIC_LOOPS):
            review = _call_llm(PS.CRITIC,
                               f"SCENE GRAPH:\n{compact}\n\nPROMPT:\n{prompt}",
                               MODELS["critic"], TEMPS["critic"])
            critique = extract_json(review)
            if critique.get("ok"): return prompt
            prompt = self.compose(graph)  # regenerate (simple but effective)
            log.info(f"Critic pass {i+1}: {critique.get('fix')}")
        raise RuntimeError("Critic unsatisfied after loops")

    # 5.5  finalize
    def finalize(self, prompt: str) -> str:
        return _call_llm(PS.FINAL, prompt, MODELS["finalizer"], TEMPS["finalizer"])

    # 5.6  public
    def build_prompt(self, problem: str) -> Dict:
        start_prompt_tokens  = meter.prompt
        start_completion_tokens = meter.complete
        start_cost = meter.cost
        t0 = time.time()

        ptxt  = self.preprocess(problem)
        graph = self.extract_scene_graph(ptxt)
        draft = self.compose(graph)
        good  = self.critic_loop(graph, draft)
        final = self.finalize(good)

        dt_prompt   = meter.prompt   - start_prompt_tokens
        dt_complete = meter.complete - start_completion_tokens
        dt_cost     = round(meter.cost - start_cost, 5)

        return {
            "problem_text": ptxt,
            "scene_graph":  graph,
            "final_prompt": final,
            "gen_time_sec": round(time.time() - t0, 2),
            "prompt_tokens": dt_prompt,
            "completion_tokens": dt_complete,
            "cost_usd": dt_cost
        }

    def close(self):
        self.cache.close()

# ─────────────────────────────────────────────────────────────────────────────
# 6.   simple driver (reads files of problems)
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse, sys
    parser = argparse.ArgumentParser(description="Physics → DALL·E prompt builder")
    parser.add_argument("file", nargs="+",
                        help="Text file(s) of physics problems (double-newline separated)")
    args = parser.parse_args()

    pipe = DallePromptPipeline()
    for fname in args.file:
        with open(fname) as fh:
            problems = [p.strip() for p in fh.read().split("\n\n") if p.strip()]
        for idx, prob in enumerate(problems, 1):
            log.info(f"[{fname}] Problem {idx}/{len(problems)}")
            data = pipe.build_prompt(prob)
            print("\n┌─ FINAL PROMPT ───────────────────────────────────────────────")
            print(data["final_prompt"])
            print("└──────────────────────────────────────────────────────────────")
            print(f"  ⏱ {data['gen_time_sec']} s | "
                  f"{data['prompt_tokens']}p + {data['completion_tokens']}c toks | "
                  f"${data['cost_usd']:.4f}")
    pipe.close()
    log.info(f"TOTAL COST this run: ${meter.cost:.4f}")

