#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Physics Problem to Diagram Prompt Generator

A streamlined pipeline that transforms physics problem text into precise DALL·E prompts
using OpenAI's API services, designed to run on modest hardware.
"""

import os
import json
import re
import logging
import base64
from typing import Dict, List, Optional, Any
from io import BytesIO
from PIL import Image
import requests
from openai import OpenAI

# === Configuration =========================================================
# API key can be set here or as environment variable
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "sk-...")
# Budget ceiling per problem
BUDGET_CEILING = 0.03
# Enable vision-language QA loop for accuracy verification
USE_VQA_LOOP = True
# Maximum correction iterations to prevent infinite loops
MAX_CORRECTION_LOOPS = 2
# Logging level
LOG_LEVEL = logging.INFO

# Configure logging
logging.basicConfig(
    level=LOG_LEVEL,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("physics_visualizer")

# Initialize OpenAI client
client = OpenAI(api_key=OPENAI_API_KEY)

# === Cost Tracking =========================================================
class TokenTracker:
    """Simple tracker for API usage and costs."""

    COST_PER_1K = {
        "gpt-4o": 0.01,
        "gpt-4o-mini": 0.00015,
        "gpt-3.5-turbo": 0.0015,
        "gpt-4-vision": 0.015,
        "dalle-3": 0.04,  # Fixed cost per image
    }

    def __init__(self, budget_ceiling=BUDGET_CEILING):
        self.token_counts = {model: 0 for model in self.COST_PER_1K}
        self.budget_ceiling = budget_ceiling
        self.total_cost = 0.0

    def add_tokens(self, model: str, tokens: int) -> None:
        """Record token usage and update total cost."""
        self.token_counts[model] = self.token_counts.get(model, 0) + tokens

        if model == "dalle-3":
            self.total_cost += self.COST_PER_1K[model]  # Fixed cost per image
        else:
            self.total_cost += (tokens / 1000) * self.COST_PER_1K.get(model, 0)

        if self.total_cost > self.budget_ceiling:
            logger.warning(f"Budget ceiling of ${self.budget_ceiling:.4f} exceeded: ${self.total_cost:.4f}")

    def get_report(self) -> str:
        """Generate cost report."""
        report = "Cost Report:\n"
        for model, tokens in self.token_counts.items():
            if model == "dalle-3":
                cost = self.COST_PER_1K[model] * (tokens if tokens > 0 else 0)
                report += f"  {model}: {tokens} images, ${cost:.4f}\n"
            else:
                cost = (tokens / 1000) * self.COST_PER_1K.get(model, 0)
                report += f"  {model}: {tokens} tokens, ${cost:.4f}\n"
        report += f"Total cost: ${self.total_cost:.4f}"
        return report

# Initialize token tracker
token_tracker = TokenTracker()

# === Core Functions ========================================================

def preprocess(problem_text: str) -> str:
    """Clean and normalize the problem text."""
    logger.info("Preprocessing problem text...")

    # Remove excess whitespace
    text = re.sub(r'\s+', ' ', problem_text.strip())

    # Convert word numbers to digits
    word_to_digit = {
        'zero': '0', 'one': '1', 'two': '2', 'three': '3', 'four': '4',
        'five': '5', 'six': '6', 'seven': '7', 'eight': '8', 'nine': '9', 'ten': '10'
    }

    for word, digit in word_to_digit.items():
        text = re.sub(r'\b' + word + r'\b', digit, text, flags=re.IGNORECASE)

    # Standardize units
    unit_map = {
        r'\bkilograms?\b': 'kg', r'\bmeters?\b': 'm', r'\bseconds?\b': 's',
        r'\bnewtons?\b': 'N', r'\bjoules?\b': 'J', r'\bdegrees?\b': '°'
    }

    for pattern, replacement in unit_map.items():
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

    return text

def extract_scene_graph(clean_text: str) -> Dict:
    """Extract structured scene graph using GPT-4o-mini."""
    logger.info("Extracting scene graph...")

    system_prompt = """Extract a precise physics scene graph from this problem. Identify:
1. All physical objects (masses, surfaces, pulleys)
2. All forces (gravity, tension, friction)
3. Physical relationships (contacts, connections)
4. Angles or measurements
5. Appropriate diagram style

Output ONLY valid JSON with these keys:
{
  "objects": [{"id": "obj1", "type": "mass", "properties": {"weight": "5kg", "position": "on_incline"}}],
  "forces": [{"id": "f1", "type": "gravity", "source": "obj1", "target": "downward"}],
  "relationships": [{"id": "r1", "type": "contact", "object1": "mass", "object2": "surface"}],
  "measurements": [{"id": "m1", "type": "angle", "value": "30°", "objects": ["incline", "horizontal"]}],
  "style": "2D side view with arrows for forces"
}

Ensure JSON is valid with no trailing commas. No explanations outside the JSON."""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": clean_text}
            ],
            temperature=0.0,
            max_tokens=800
        )

        # Track token usage
        token_tracker.add_tokens("gpt-4o-mini",
                              response.usage.prompt_tokens + response.usage.completion_tokens)

        # Extract and parse JSON
        json_text = response.choices[0].message.content.strip()
        json_text = re.sub(r'^```json|^```|```$', '', json_text)

        scene_graph = json.loads(json_text)

        # Validate required keys
        required_keys = ["objects", "forces", "style"]
        for key in required_keys:
            if key not in scene_graph:
                raise ValueError(f"Missing required key: {key}")

        return scene_graph

    except Exception as e:
        logger.error(f"Scene graph extraction error: {e}")
        raise

def compose_prompt(scene_graph: Dict) -> str:
    """Create a DALL·E-ready prompt from the scene graph."""
    logger.info("Composing image prompt...")

    system_prompt = """Create a DALL·E 3 prompt for a physics diagram following these rules:

1. Start with "A professional physics textbook diagram showing" and the main scenario
2. Use exact object counts: "A 5kg box" not "boxes"
3. Specify force arrows precisely: "with a red arrow pointing downward labeled 'Gravity'"
4. Include all measurements with exact values: "a 30° inclined plane"
5. End with "Diagram in clean 2D physics textbook style with white background and labeled forces"

The prompt must be a single paragraph with every object and force specified."""

    scene_description = json.dumps(scene_graph, indent=2)

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Create a DALL·E 3 prompt for this physics scene:\n\n{scene_description}"}
            ],
            temperature=0.3,
            max_tokens=800
        )

        # Track token usage
        token_tracker.add_tokens("gpt-4o",
                              response.usage.prompt_tokens + response.usage.completion_tokens)

        return response.choices[0].message.content

    except Exception as e:
        logger.error(f"Prompt composition error: {e}")
        raise

def generate_image_dall_e(prompt: str, quality="standard") -> str:
    """Generate an image using DALL·E 3."""
    logger.info(f"Generating {quality} image with DALL·E...")

    try:
        response = client.images.generate(
            model="dall-e-3",
            prompt=prompt,
            size="1024x1024",
            quality=quality,
            n=1
        )

        # Track token usage
        token_tracker.add_tokens("dalle-3", 1)

        return response.data[0].url

    except Exception as e:
        logger.error(f"DALL·E image generation error: {e}")
        return None

def load_image_from_url(url: str) -> Image.Image:
    """Load an image from a URL."""
    response = requests.get(url)
    return Image.open(BytesIO(response.content))

def encode_image_for_api(image: Image.Image) -> str:
    """Encode an image for GPT-4 Vision API."""
    buffered = BytesIO()
    image.save(buffered, format="PNG")
    return base64.b64encode(buffered.getvalue()).decode('utf-8')

def vision_check(image_url: str, scene_graph: Dict) -> List[Dict]:
    """Check image accuracy using GPT-4 Vision."""
    logger.info("Performing vision-based accuracy check...")

    if not USE_VQA_LOOP:
        logger.info("Vision QA loop disabled, skipping check")
        return []

    try:
        # Load the image
        image = load_image_from_url(image_url)
        base64_image = encode_image_for_api(image)

        # Prepare questions based on scene graph
        questions = []

        # Object count questions
        for obj_type in set(obj["type"] for obj in scene_graph["objects"]):
            count = sum(1 for obj in scene_graph["objects"] if obj["type"] == obj_type)
            questions.append(f"How many {obj_type}s are in the image? The correct answer is {count}.")

        # Force arrow questions
        for force in scene_graph["forces"]:
            questions.append(f"Is there an arrow representing {force['type']} force? The answer should be yes.")

        # Angle questions
        if "measurements" in scene_graph:
            for meas in scene_graph["measurements"]:
                if meas["type"] == "angle":
                    questions.append(f"What is the angle value shown? The correct value is {meas['value']}.")

        # Combine questions
        question_text = "Analyze this physics diagram image and answer these questions:\n"
        question_text += "\n".join(f"{i+1}. {q}" for i, q in enumerate(questions))
        question_text += "\n\nFor each question, indicate if the diagram is CORRECT or INCORRECT. If incorrect, explain why."

        # Send to GPT-4 Vision
        response = client.chat.completions.create(
            model="gpt-4-vision-preview",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": question_text},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=1000
        )

        # Track token usage (rough estimate for vision)
        token_tracker.add_tokens("gpt-4-vision", 1000)

        # Process the response to identify failures
        analysis_text = response.choices[0].message.content

        # Extract failures
        failures = []
        for i, question in enumerate(questions):
            section = analysis_text.split(f"{i+1}.")[1].split(f"{i+2}.")[0] if i+2 <= len(questions) else analysis_text.split(f"{i+1}.")[1]
            if "INCORRECT" in section:
                # Create a failure entry
                if "how many" in question.lower():
                    obj_type = re.search(r'how many (\w+)s?', question.lower()).group(1)
                    expected = re.search(r'correct answer is (\d+)', question).group(1)
                    failures.append({
                        "type": "object_count",
                        "object_type": obj_type,
                        "expected": expected
                    })
                elif "arrow" in question.lower():
                    force_type = re.search(r'arrow representing (\w+) force', question.lower()).group(1)
                    failures.append({
                        "type": "missing_force",
                        "force_type": force_type
                    })
                elif "angle" in question.lower():
                    expected = re.search(r'correct value is ([\d°]+)', question).group(1)
                    failures.append({
                        "type": "incorrect_angle",
                        "expected": expected
                    })

        logger.info(f"Vision check found {len(failures)} issues")
        return failures

    except Exception as e:
        logger.error(f"Vision check error: {e}")
        return []

def auto_patch(prompt: str, failures: List[Dict]) -> str:
    """Improve the prompt based on vision check failures."""
    logger.info("Auto-patching prompt...")

    if not failures:
        return prompt

    patched_prompt = prompt

    # Handle each type of failure
    for failure in failures:
        if failure["type"] == "object_count":
            obj_type = failure["object_type"]
            expected = failure["expected"]

            # Add or emphasize object count
            if obj_type.lower() in patched_prompt.lower():
                patched_prompt = re.sub(
                    rf"(\w+\s+){obj_type}s?",
                    f"exactly {expected} {obj_type}{'s' if int(expected) > 1 else ''}",
                    patched_prompt,
                    flags=re.IGNORECASE
                )
            else:
                patched_prompt += f" Include exactly {expected} {obj_type}{'s' if int(expected) > 1 else ''}."

        elif failure["type"] == "missing_force":
            force_type = failure["force_type"]
            patched_prompt += f" Show a prominent arrow labeled '{force_type}' to represent this force."

        elif failure["type"] == "incorrect_angle":
            expected = failure["expected"]
            patched_prompt += f" The angle must be exactly {expected} and clearly labeled."

    # Add general improvements
    patched_prompt += " Use clear labels and distinct colors for different forces."

    return patched_prompt

def finalize_prompt(prompt: str) -> str:
    """Polish the prompt for final use."""
    logger.info("Finalizing prompt...")

    system_prompt = """Polish this physics diagram prompt without changing its meaning. Fix grammar and
spacing issues, but preserve all object counts, force descriptions, and measurements exactly."""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Polish this DALL·E prompt:\n\n{prompt}"}
            ],
            temperature=0.2,
            max_tokens=800
        )

        # Track token usage
        token_tracker.add_tokens("gpt-3.5-turbo",
                               response.usage.prompt_tokens + response.usage.completion_tokens)

        return response.choices[0].message.content

    except Exception as e:
        logger.error(f"Prompt finalization error: {e}")
        return prompt

# === Main Pipeline =========================================================
def generate_physics_diagram(problem_text: str, generate_hifi: bool = False) -> Dict:
    """
    Convert a physics problem into a polished DALL·E prompt with optional image.

    This pipeline processes the problem through multiple stages:
    1. Text preprocessing
    2. Scene graph extraction with GPT-4o-mini
    3. Initial prompt composition with GPT-4o
    4. Draft image generation with DALL·E (standard quality)
    5. Vision-based accuracy verification with GPT-4 Vision
    6. Automatic prompt correction
    7. Final prompt polishing with GPT-3.5-turbo
    8. Optional high-quality image generation

    Args:
        problem_text: The physics problem to visualize
        generate_hifi: Whether to generate a final high-quality image

    Returns:
        Dictionary with the final prompt and image URLs
    """
    logger.info("Starting physics diagram generation pipeline...")

    # Track the best prompt seen
    best_prompt = None
    draft_image_url = None
    hifi_image_url = None

    try:
        # Phase 1: Preprocess the text
        clean_text = preprocess(problem_text)

        # Phase 2: Extract scene graph
        scene_graph = extract_scene_graph(clean_text)

        # Phase 3: Compose initial prompt
        prompt = compose_prompt(scene_graph)
        best_prompt = prompt

        # Phases 4-6: VQA Loop
        if USE_VQA_LOOP:
            for iteration in range(MAX_CORRECTION_LOOPS):
                logger.info(f"Starting vision check loop {iteration+1}/{MAX_CORRECTION_LOOPS}")

                # Generate draft image with DALL·E (standard quality)
                draft_image_url = generate_image_dall_e(prompt, quality="standard")

                if not draft_image_url:
                    logger.warning("Failed to generate draft image, skipping vision check")
                    break

                # Perform vision-based accuracy check
                failures = vision_check(draft_image_url, scene_graph)

                # Exit loop if no failures
                if not failures:
                    logger.info("Vision check passed, no issues detected")
                    best_prompt = prompt
                    break

                # Auto-patch the prompt
                prompt = auto_patch(prompt, failures)

                # Only update best prompt if it's better
                if len(failures) < len(vision_check(draft_image_url, scene_graph) or []):
                    best_prompt = prompt

        # Phase 7: Finalize the prompt
        final_prompt = finalize_prompt(best_prompt)

        # Phase 8: Generate high-quality image if requested
        if generate_hifi and token_tracker.total_cost + token_tracker.COST_PER_1K["dalle-3"] <= token_tracker.budget_ceiling:
            hifi_image_url = generate_image_dall_e(final_prompt, quality="hd")

        # Log usage report
        logger.info(token_tracker.get_report())

        return {
            "final_prompt": final_prompt,
            "scene_graph": scene_graph,
            "draft_image_url": draft_image_url,
            "hifi_image_url": hifi_image_url,
            "total_cost": token_tracker.total_cost
        }

    except Exception as e:
        logger.error(f"Pipeline error: {e}")
        return {
            "final_prompt": best_prompt,
            "error": str(e),
            "total_cost": token_tracker.total_cost
        }

# === Script Execution ======================================================
if __name__ == "__main__":
    # Example physics problem
    PROBLEM_TEXT = """A 5 kg box sits on a frictionless inclined plane that makes an angle of 30° with the horizontal. A force F of magnitude 10 N acts on the box parallel to the inclined plane and directed up the plane. Determine the acceleration of the box."""

    # Run the pipeline
    result = generate_physics_diagram(PROBLEM_TEXT)

    # Display results
    print("\nFINAL PROMPT:")
    print("-" * 80)
    print(result["final_prompt"])
    print("-" * 80)

    if result.get("draft_image_url"):
        print(f"\nDraft image URL: {result['draft_image_url']}")

    print(f"\nTotal cost: ${result['total_cost']:.4f}")